---
title: "Privacy Policy"
description: ""
summary: ""
date: 2023-09-07T17:19:07+02:00
lastmod: 2023-09-07T17:19:07+02:00
draft: false
type: "legal"
seo:
  title: "" # custom title (optional)
  description: "" # custom description (recommended)
  canonical: "" # custom canonical URL (optional)
  noindex: false # false (default) or true
---
