---
slug: "api-restful"
title: "APIs RESTful"
summary: "Projeto e implementação de APIs seguindo princípios REST."
tags:
  - "api"
  - "rest"
youtube_playlists: []
contributors: []
---

Define endpoints, métodos HTTP, serialização, tratamento de erros e documentação (OpenAPI).
