---
slug: "performance-web"
title: "Performance Web"
summary: "Estratégias de otimização de carregamento e resposta."
tags:
  - "performance"
  - "otimizacao"
youtube_playlists: []
contributors: []
---

Inclui minificação, bundling, lazy loading, caching e uso de ferramentas como Lighthouse.
