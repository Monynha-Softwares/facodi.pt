---
slug: "front-end-framework"
title: "Frameworks Front-end"
summary: "Componentes, roteamento e gestão de estado em frameworks modernos."
tags:
  - "frontend"
  - "framework"
youtube_playlists: []
contributors: []
---

Mostra padrões de componentização, hooks ou reatividade, bibliotecas de UI e integração com roteadores.
