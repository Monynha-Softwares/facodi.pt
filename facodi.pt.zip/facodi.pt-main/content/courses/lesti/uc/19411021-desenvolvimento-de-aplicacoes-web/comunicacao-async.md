---
slug: "comunicacao-async"
title: "Comunicação Assíncrona"
summary: "AJAX/fetch, CORS e WebSockets para tempo real."
tags:
  - "ajax"
  - "websocket"
youtube_playlists: []
contributors: []
---

Explica chamadas assíncronas, gestão de promessas, configuração de CORS e uso de sockets para aplicações reativas.
