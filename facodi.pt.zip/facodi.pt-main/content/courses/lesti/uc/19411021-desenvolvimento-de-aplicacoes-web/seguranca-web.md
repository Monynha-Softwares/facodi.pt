---
slug: "seguranca-web"
title: "Segurança Web"
summary: "Mitigação de vulnerabilidades como SQLi, XSS e CSRF."
tags:
  - "seguranca"
  - "owasp"
youtube_playlists: []
contributors: []
---

Aplica validação de entrada, prepared statements, sanitização e cabeçalhos de segurança, além de autenticação segura.
