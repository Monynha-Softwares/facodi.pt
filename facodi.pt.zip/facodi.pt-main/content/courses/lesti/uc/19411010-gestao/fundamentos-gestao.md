---
slug: "fundamentos-gestao"
title: "Fundamentos de Gestão"
summary: "Funções administrativas e principais escolas de pensamento em gestão."
tags:
  - "gestao"
  - "teorias"
youtube_playlists: []
contributors: []
---

Sintetiza teorias clássicas, comportamentais e sistémicas e relaciona-as às funções de planear, organizar, liderar e controlar.
