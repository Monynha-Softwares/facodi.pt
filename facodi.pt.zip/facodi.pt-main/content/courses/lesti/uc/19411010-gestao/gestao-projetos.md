---
slug: "gestao-projetos"
title: "Gestão de Projetos"
summary: "Ciclo de vida do projeto, abordagens tradicionais e ágeis."
tags:
  - "projetos"
  - "agil"
youtube_playlists: []
contributors: []
---

Discute iniciação, planeamento de escopo, cronograma, orçamento, execução, monitorização e encerramento comparando PMBOK, Scrum e Kanban.
