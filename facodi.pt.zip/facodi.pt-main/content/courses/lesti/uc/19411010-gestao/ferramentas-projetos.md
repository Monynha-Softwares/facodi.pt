---
slug: "ferramentas-projetos"
title: "Ferramentas de Projetos"
summary: "Software de suporte, WBS, cronogramas e técnicas ágeis."
tags:
  - "software"
  - "planeamento"
youtube_playlists: []
contributors: []
---

Explora MS Project, quadros ágeis, estrutura analítica do projeto, gráficos de Gantt, sprints e retrospectivas.
