---
slug: "planeamento-estrategico"
title: "Planeamento Estratégico"
summary: "Análise SWOT, definição de objetivos e planos de ação."
tags:
  - "estrategia"
  - "marketing"
youtube_playlists: []
contributors: []
---

Apresenta etapas para formular estratégias, selecionar indicadores e alinhar marketing aos objetivos corporativos.
