---
slug: "organizacao-empresarial"
title: "Organização Empresarial"
summary: "Estruturas funcionais, divisionais e matriciais e mecanismos de coordenação."
tags:
  - "organizacao"
  - "estrutura"
youtube_playlists: []
contributors: []
---

Analisa distribuição de tarefas, comunicação interna, centralização vs. descentralização e desenho organizacional.
