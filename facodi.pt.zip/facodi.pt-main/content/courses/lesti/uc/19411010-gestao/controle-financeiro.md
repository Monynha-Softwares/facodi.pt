---
slug: "controle-financeiro"
title: "Controlo Financeiro"
summary: "Orçamentação, análise de investimentos e indicadores financeiros."
tags:
  - "financas"
  - "indicadores"
youtube_playlists: []
contributors: []
---

Introduce cash flow, payback, VPL e ferramentas de controlo para suportar decisões de investimento.
