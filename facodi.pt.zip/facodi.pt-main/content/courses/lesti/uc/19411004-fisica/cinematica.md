---
slug: "cinematica"
title: "Cinemática"
summary: "Movimento de um ponto material, vetores posição, velocidade e aceleração."
tags:
  - "movimento"
  - "trajetoria"
youtube_playlists: []
contributors: []
---

Estuda componentes cartesianos, tangenciais e normais de velocidade e aceleração em trajetórias diversas.
