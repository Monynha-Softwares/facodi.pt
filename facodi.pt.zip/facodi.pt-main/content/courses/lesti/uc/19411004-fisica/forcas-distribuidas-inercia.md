---
slug: "forcas-distribuidas-inercia"
title: "Forças Distribuídas e Inércia"
summary: "Centros de massa e momentos de inércia de áreas e massas."
tags:
  - "momento-inercia"
  - "centro-massa"
youtube_playlists: []
contributors: []
---

Calcula centros de massa por decomposição, aplica o teorema dos eixos paralelos e interpreta resultados em estruturas reais.
