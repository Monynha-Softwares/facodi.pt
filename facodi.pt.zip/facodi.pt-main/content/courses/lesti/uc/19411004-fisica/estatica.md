---
slug: "estatica"
title: "Estática"
summary: "Equilíbrio de partículas e corpos rígidos, resultantes e atrito."
tags:
  - "equilibrio"
  - "forcas"
youtube_playlists: []
contributors: []
---

Analisa sistemas equivalentes de forças, condições de equilíbrio em 2D/3D e efeitos de atrito estático e cinético.
