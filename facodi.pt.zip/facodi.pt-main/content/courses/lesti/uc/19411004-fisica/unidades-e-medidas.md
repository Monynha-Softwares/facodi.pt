---
slug: "unidades-e-medidas"
title: "Unidades e Medidas"
summary: "Sistema Internacional, análise dimensional e representação numérica."
tags:
  - "si"
  - "dimensional"
youtube_playlists: []
contributors: []
---

Explora grandezas físicas, notação científica e algarismos significativos para avaliar coerência de expressões físicas.
