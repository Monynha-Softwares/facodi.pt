---
slug: "oscilacoes-ondas"
title: "Oscilações e Ondas"
summary: "Movimento harmónico simples, circular uniforme e ondas mecânicas."
tags:
  - "oscilacoes"
  - "ondas"
youtube_playlists: []
contributors: []
---

Modela sistemas massa-mola, pêndulos e ondas em cordas, interpretando frequência, amplitude e fase.
