---
slug: "dinamica"
title: "Dinâmica"
summary: "Aplicação da 2ª Lei de Newton e equações de movimento."
tags:
  - "newton"
  - "equacoes"
youtube_playlists: []
contributors: []
---

Deriva equações diferenciais do movimento para sistemas sob forças variadas e avalia equilíbrio dinâmico.
