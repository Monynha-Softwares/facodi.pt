---
slug: "trabalho-e-energia"
title: "Trabalho e Energia"
summary: "Energia cinética, potencial e conservação da energia mecânica."
tags:
  - "energia"
  - "trabalho"
youtube_playlists: []
contributors: []
---

Quantifica trabalho realizado por forças e aplica conservação de energia a sistemas conservativos e dissipativos.
