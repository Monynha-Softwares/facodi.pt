---
slug: "conteudos-variaveis"
title: "Conteúdos Variáveis"
summary: "Programa definido conforme a UC optativa escolhida."
tags:
  - "optativa"
  - "personalizacao"
youtube_playlists: []
contributors: []
---

Cada optativa possui tópicos próprios, definidos na respetiva ficha oficial, permitindo personalizar a formação.
