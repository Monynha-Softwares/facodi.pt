---
slug: "optativa-variavel-ee"
title: "Optativa Variável EE"
summary: "Conteúdos variáveis conforme a UC escolhida."
tags:
  - "optativa"
  - "ee"
youtube_playlists: []
contributors: []
---

A carga temática depende da unidade cursada, abrangendo tópicos selecionados da área de eletrónica, energia ou similares.
