---
title: "Opção III UAlg/ISE"
code: "19411039"
description: "Unidade optativa alternativa à Computação Reconfigurável, escolhida conforme oferta e interesse do aluno."
ects: 5
semester: 4
language: "pt"
prerequisites: []
learning_outcomes:
  - "Selecionar uma UC optativa coerente com o percurso profissional desejado."
  - "Atingir os objetivos de aprendizagem definidos pela unidade escolhida."
  - "Relatar resultados e competências obtidas na optativa realizada."
youtube_playlists: []
summary: "Opcional de 5 ECTS para complementar a formação na pista de Eletrónica e Energia ou outras áreas afins."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

## Conteúdos Programáticos

Definidos pela UC optativa selecionada dentro da oferta semestral da UAlg/ISE para 5 ECTS, permitindo alternativas à Computação Reconfigurável.
