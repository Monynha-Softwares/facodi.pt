---
slug: "regressao-linear"
title: "Regressão Linear"
summary: "Modelos lineares simples, correlação e análise de resíduos."
tags:
  - "regressao"
  - "correlacao"
youtube_playlists: []
contributors: []
---

Apresenta método dos mínimos quadrados, coeficiente de correlação e avaliação de ajustamento.
