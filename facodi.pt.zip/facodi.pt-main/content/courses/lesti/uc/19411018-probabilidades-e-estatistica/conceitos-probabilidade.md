---
slug: "conceitos-probabilidade"
title: "Conceitos de Probabilidade"
summary: "Eventos, axiomas de Kolmogorov e teorema de Bayes."
tags:
  - "probabilidade"
  - "bayes"
youtube_playlists: []
contributors: []
---

Apresenta operações com eventos e aplicação de Bayes em problemas reais.
