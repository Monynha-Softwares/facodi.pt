---
slug: "testagem-hipoteses"
title: "Testagem de Hipóteses"
summary: "Testes z, t e qui-quadrado, níveis de significância e p-valor."
tags:
  - "hipotese"
  - "teste"
youtube_playlists: []
contributors: []
---

Ensina formulação de H0/H1, cálculo de estatísticas e interpretação de resultados incluindo erros tipo I/II.
