---
slug: "inferencias-estatisticas"
title: "Inferências Estatísticas"
summary: "Amostragem, distribuição amostral e intervalos de confiança."
tags:
  - "inferencias"
  - "intervalos"
youtube_playlists: []
contributors: []
---

Trata estimadores, erro padrão e construção de intervalos para média e proporção.
