---
slug: "variaveis-aleatorias"
title: "Variáveis Aleatórias"
summary: "Distribuições discretas (Binomial, Poisson) e contínuas (Uniforme, Normal)."
tags:
  - "variaveis"
  - "distribuicoes"
youtube_playlists: []
contributors: []
---

Explora cálculo de esperança, variância e interpretação de distribuições em contextos de engenharia.
