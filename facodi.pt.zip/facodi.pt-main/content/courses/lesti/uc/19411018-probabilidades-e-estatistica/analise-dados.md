---
slug: "analise-dados"
title: "Análise de Dados"
summary: "Estatística descritiva e visualização básica."
tags:
  - "estatistica"
  - "descricao"
youtube_playlists: []
contributors: []
---

Cobre média, mediana, moda, desvio padrão, histogramas, boxplots e gráficos de dispersão.
