---
slug: "normas-e-politicas"
title: "Normas e Políticas"
summary: "ISO 27001, NIST e elaboração de políticas de segurança."
tags:
  - "normas"
  - "politicas"
youtube_playlists: []
contributors: []
---

Apresenta frameworks de governação, definição de políticas e procedimentos de auditoria.
