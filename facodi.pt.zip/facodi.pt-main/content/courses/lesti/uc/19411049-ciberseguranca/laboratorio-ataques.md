---
slug: "laboratorio-ataques"
title: "Laboratório de Ataques e Defesa"
summary: "Exercícios práticos de pen test e hardening em ambiente controlado."
tags:
  - "laboratorio"
  - "pentest"
youtube_playlists: []
contributors: []
---

Inclui scanning com Nmap, exploração de vulnerabilidades de demonstração e posterior correção.
