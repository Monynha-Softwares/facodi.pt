---
slug: "seguranca-web"
title: "Segurança Web"
summary: "Vulnerabilidades OWASP e defesas correspondentes."
tags:
  - "owasp"
  - "web"
youtube_playlists: []
contributors: []
---

Estuda injeções, XSS, CSRF, gestão de sessões, hashing seguro de senhas e cabeçalhos de segurança.
