---
slug: "criptografia-basica"
title: "Criptografia Básica"
summary: "Algoritmos simétricos, assimétricos, hash e assinaturas."
tags:
  - "criptografia"
  - "hash"
youtube_playlists: []
contributors: []
---

Explora AES, RSA, SHA, certificados digitais e práticas de gestão de chaves.
