---
slug: "seguranca-sistemas"
title: "Segurança de Sistemas"
summary: "Hardening, patch management e resposta a malware."
tags:
  - "hardening"
  - "malware"
youtube_playlists: []
contributors: []
---

Apresenta controlo de acessos, permissões em Windows/Linux e técnicas para mitigar malware.
