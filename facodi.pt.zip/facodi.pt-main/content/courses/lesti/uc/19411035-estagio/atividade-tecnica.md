---
slug: "atividade-tecnica"
title: "Atividade Técnica"
summary: "Execução das tarefas previstas no plano de estágio."
tags:
  - "atividades"
  - "tecnico"
youtube_playlists: []
contributors: []
---

Abrange desenvolvimento de software, administração de sistemas ou outras atividades definidas.
