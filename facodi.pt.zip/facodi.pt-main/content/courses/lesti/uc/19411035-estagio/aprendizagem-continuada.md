---
slug: "aprendizagem-continuada"
title: "Aprendizagem Continuada"
summary: "Aquisição de novas competências e ferramentas durante o estágio."
tags:
  - "aprendizagem"
  - "competencias"
youtube_playlists: []
contributors: []
---

Inclui autoestudo, formações internas e adaptação a tecnologias não cobertas no curso.
