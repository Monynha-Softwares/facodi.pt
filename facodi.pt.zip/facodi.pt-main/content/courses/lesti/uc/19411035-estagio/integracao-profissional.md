---
slug: "integracao-profissional"
title: "Integração Profissional"
summary: "Ambientação à empresa, cultura, processos e comunicação."
tags:
  - "integracao"
  - "empresa"
youtube_playlists: []
contributors: []
---

Envolve conhecer estrutura organizacional, ferramentas internas e estabelecer relações profissionais.
