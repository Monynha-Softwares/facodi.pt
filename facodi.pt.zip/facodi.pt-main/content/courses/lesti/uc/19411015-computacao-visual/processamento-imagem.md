---
slug: "processamento-imagem"
title: "Processamento de Imagem"
summary: "Técnicas de tratamento digital de imagens 2D."
tags:
  - "imagem"
  - "filtros"
youtube_playlists: []
contributors: []
---

Apresenta filtros espaciais, deteção de contornos, transformações morfológicas e ajustes de intensidade.
