---
slug: "interacao-3d"
title: "Interação 3D"
summary: "Dispositivos e técnicas de interação homem-máquina em cenários visuais."
tags:
  - "ihm"
  - "dispositivos"
youtube_playlists: []
contributors: []
---

Estuda interfaces como VR/AR, sensores de profundidade e design centrado no utilizador para aplicações visuais.
