---
slug: "computacao-grafica"
title: "Computação Gráfica"
summary: "Fundamentos de pipelines gráficos e modelação geométrica."
tags:
  - "grafica"
  - "renderizacao"
youtube_playlists: []
contributors: []
---

Trata renderização 3D, malhas poligonais, texturas e introdução a APIs como OpenGL ou bibliotecas equivalentes.
