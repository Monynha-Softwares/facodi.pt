---
slug: "visao-computacional"
title: "Visão Computacional"
summary: "Deteção e reconhecimento de objetos, faces e poses."
tags:
  - "visao"
  - "reconhecimento"
youtube_playlists: []
contributors: []
---

Explora métodos clássicos e baseados em ML para reconhecimento e estimação de pose usando OpenCV/MediaPipe.
