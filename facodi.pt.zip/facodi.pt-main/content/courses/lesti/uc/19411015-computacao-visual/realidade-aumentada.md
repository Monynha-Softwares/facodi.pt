---
slug: "realidade-aumentada"
title: "Realidade Aumentada"
summary: "Integração de objetos virtuais com o ambiente real."
tags:
  - "ar"
  - "rastreamento"
youtube_playlists: []
contributors: []
---

Aborda calibração de câmara, rastreamento de marcadores e sobreposição em tempo real para experiências AR.
