---
slug: "projeto-integrador-visual"
title: "Projeto Integrador Visual"
summary: "Projeto prático combinando gráficos, imagem e visão computacional."
tags:
  - "projeto"
  - "computacao-visual"
youtube_playlists: []
contributors: []
---

Planeia e implementa uma aplicação visual completa usando ferramentas como Blender, OpenCV e Python.
