---
slug: "flet-framework"
title: "Framework Flet"
summary: "Construção de interfaces multiplataforma com Python."
tags:
  - "flet"
  - "python"
youtube_playlists: []
contributors: []
---

Apresenta arquitetura cliente-servidor do Flet, componentes disponíveis e fluxo de execução.
