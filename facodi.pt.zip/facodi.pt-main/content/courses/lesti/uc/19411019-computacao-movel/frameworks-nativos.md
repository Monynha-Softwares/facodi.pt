---
slug: "frameworks-nativos"
title: "Frameworks Nativos"
summary: "Arquitetura de Flutter, React Native ou Kotlin Multiplatform."
tags:
  - "flutter"
  - "react-native"
youtube_playlists: []
contributors: []
---

Apresenta estrutura de projeto, widgets declarativos, navegação e integração com serviços do dispositivo.
