---
slug: "mobile-hardware"
title: "Hardware Móvel"
summary: "Características de CPU, memória, sensores e conectividade em dispositivos móveis."
tags:
  - "hardware"
  - "sensores"
youtube_playlists: []
contributors: []
---

Examines restrições de bateria, sensores disponíveis e impacto no design de aplicações eficientes.
