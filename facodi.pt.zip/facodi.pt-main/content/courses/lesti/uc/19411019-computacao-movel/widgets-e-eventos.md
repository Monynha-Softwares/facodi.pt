---
slug: "widgets-e-eventos"
title: "Widgets e Eventos"
summary: "Layouts, navegação, gestão de estado e eventos em Flet/Flutter."
tags:
  - "widgets"
  - "estado"
youtube_playlists: []
contributors: []
---

Explora componentes prontos, organização de layouts, navegação entre páginas e manipulação de eventos de utilizador.
