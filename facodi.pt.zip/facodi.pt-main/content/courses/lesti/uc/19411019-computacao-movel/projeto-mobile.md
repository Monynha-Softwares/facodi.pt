---
slug: "projeto-mobile"
title: "Projeto Mobile"
summary: "Desenvolvimento de app completa com consumo de APIs e persistência."
tags:
  - "projeto"
  - "mobile"
youtube_playlists: []
contributors: []
---

Propõe criar aplicação de tarefas ou cliente API com design responsivo, armazenamento local e sincronização online.
