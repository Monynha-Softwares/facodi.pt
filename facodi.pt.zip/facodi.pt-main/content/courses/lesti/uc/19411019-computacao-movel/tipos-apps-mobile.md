---
slug: "tipos-apps-mobile"
title: "Tipos de Apps"
summary: "Comparação entre apps nativas, web e híbridas."
tags:
  - "nativo"
  - "hibrido"
youtube_playlists: []
contributors: []
---

Analisa vantagens e limitações de cada abordagem, incluindo frameworks multiplataforma.
