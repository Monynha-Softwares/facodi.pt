---
slug: "equacoes-diferenciais"
title: "Equações Diferenciais"
summary: "Equações diferenciais de primeira ordem e lineares de ordem superior."
tags:
  - "edo"
  - "diferenciais"
youtube_playlists: []
contributors: []
---

Trabalha métodos de separação de variáveis, fator integrante, equações homogéneas e não homogéneas, e o método dos coeficientes indeterminados para resolver sistemas lineares de EDOs.
