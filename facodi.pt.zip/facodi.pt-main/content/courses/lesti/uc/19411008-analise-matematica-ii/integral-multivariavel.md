---
slug: "integral-multivariavel"
title: "Integral Multivariável"
summary: "Integração múltipla, mudança de variáveis e teoremas clássicos de campos vetoriais."
tags:
  - "integrais"
  - "campos"
youtube_playlists: []
contributors: []
---

Estuda integrais duplos e triplos, coordenadas polares/cilíndricas/esféricas, integrais de linha e superfície e os teoremas de Green, Stokes e Gauss.
