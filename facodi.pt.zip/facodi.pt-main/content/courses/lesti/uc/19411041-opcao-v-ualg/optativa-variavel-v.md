---
slug: "optativa-variavel-v"
title: "Optativa Variável V"
summary: "Conteúdos definidos pela unidade selecionada."
tags:
  - "optativa"
  - "ee"
youtube_playlists: []
contributors: []
---

Abrange disciplinas da área de eletrónica, energia ou outras que reforcem a especialização do estudante.
