---
title: "Opção V UAlg/ISE"
code: "19411041"
description: "Optativa alternativa ao Laboratório IoT para estudantes que escolham outras unidades na pista EE ou áreas afins."
ects: 5
semester: 5
language: "pt"
prerequisites: []
learning_outcomes:
  - "Definir percurso personalizado escolhendo UC optativa adequada."
  - "Cumprir objetivos definidos na ficha da UC selecionada."
  - "Integrar aprendizagens optativas em projetos ou investigação relacionados."
youtube_playlists: []
summary: "Permite selecionar disciplinas complementares na área de eletrónica, energia ou outras, em substituição ao Laboratório IoT."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

## Conteúdos Programáticos

Dependem da UC optativa escolhida dentro da oferta de 5 ECTS disponível no semestre, substituindo Laboratório IoT conforme plano individual.
