---
slug: "documentacao-monografia"
title: "Documentação e Monografia"
summary: "Elaboração do documento final com estrutura académica."
tags:
  - "monografia"
  - "documentacao"
youtube_playlists: []
contributors: []
---

Inclui escrita de introdução, fundamentação, metodologia, resultados, conclusões e referências.
