---
slug: "metodologia-projeto"
title: "Metodologia do Projeto"
summary: "Planeamento das etapas, métodos e critérios de sucesso."
tags:
  - "metodologia"
  - "planeamento"
youtube_playlists: []
contributors: []
---

Inclui definição de cronograma, recursos, abordagens científicas ou de engenharia e métricas de avaliação.
