---
slug: "escolha-tema"
title: "Escolha do Tema"
summary: "Definição do problema e revisão preliminar do estado da arte."
tags:
  - "tema"
  - "pesquisa"
youtube_playlists: []
contributors: []
---

Abrange identificação de oportunidades, delimitação do escopo e levantamento bibliográfico inicial.
