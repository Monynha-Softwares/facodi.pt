---
slug: "defesa-projeto"
title: "Defesa do Projeto"
summary: "Apresentação pública e resposta a questões da banca."
tags:
  - "defesa"
  - "apresentacao"
youtube_playlists: []
contributors: []
---

Prepara apresentação, demonstra protótipos e defende contribuições perante avaliadores.
