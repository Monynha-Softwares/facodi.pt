---
slug: "analise-resultados"
title: "Análise de Resultados"
summary: "Testes, avaliação e comparação com expectativas ou estado da arte."
tags:
  - "analise"
  - "resultados"
youtube_playlists: []
contributors: []
---

Envolve recolha de dados, interpretação crítica e identificação de limitações e perspetivas futuras.
