---
slug: "desenho-visual"
title: "Desenho Visual"
summary: "Modelação de entidades, interfaces e fluxos através de editores visuais."
tags:
  - "ui"
  - "modelacao"
youtube_playlists: []
contributors: []
---

Mostra como definir modelos de dados, construir ecrãs com drag-and-drop e configurar regras de navegação.
