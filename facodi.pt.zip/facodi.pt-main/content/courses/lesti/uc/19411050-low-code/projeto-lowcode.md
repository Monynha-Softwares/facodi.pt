---
slug: "projeto-lowcode"
title: "Projeto Low-Code"
summary: "Construção completa de uma aplicação empresarial."
tags:
  - "projeto"
  - "low-code"
youtube_playlists: []
contributors: []
---

Conduz projeto desde requisitos até publicação, com testes de utilizador e considerações de manutenção.
