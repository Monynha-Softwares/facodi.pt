---
slug: "plataformas-lowcode"
title: "Plataformas Low-Code"
summary: "Panorama e características de ferramentas low-code/no-code."
tags:
  - "low-code"
  - "plataformas"
youtube_playlists: []
contributors: []
---

Analisa OutSystems, Power Apps, AppInventor e critérios para escolha de plataforma.
