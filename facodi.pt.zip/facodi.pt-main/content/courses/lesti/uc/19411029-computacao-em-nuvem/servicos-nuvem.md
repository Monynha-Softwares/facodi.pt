---
slug: "servicos-nuvem"
title: "Serviços em Nuvem"
summary: "Modelos IaaS, PaaS, SaaS e BaaS/FaaS."
tags:
  - "iaas"
  - "saas"
youtube_playlists: []
contributors: []
---

Detalha responsabilidades do provedor vs cliente e exemplos reais em AWS, Azure e GCP.
