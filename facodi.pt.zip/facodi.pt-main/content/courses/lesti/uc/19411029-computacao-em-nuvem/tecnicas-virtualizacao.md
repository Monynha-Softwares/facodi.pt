---
slug: "tecnicas-virtualizacao"
title: "Técnicas de Virtualização"
summary: "Hypervisors tipo 1/2 e conteinerização."
tags:
  - "virtualizacao"
  - "docker"
youtube_playlists: []
contributors: []
---

Explica isolamento, overcommitment e diferenças entre VMs tradicionais e contentores Docker.
