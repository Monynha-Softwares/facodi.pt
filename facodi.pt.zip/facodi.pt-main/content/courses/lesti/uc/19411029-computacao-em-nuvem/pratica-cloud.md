---
slug: "pratica-cloud"
title: "Prática em Cloud"
summary: "Implantação de aplicações em plataformas de nuvem."
tags:
  - "deployment"
  - "cloud"
youtube_playlists: []
contributors: []
---

Abrange criação de VMs, configuração de serviços geridos e deployment em PaaS ou serverless.
