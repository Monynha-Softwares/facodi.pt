---
slug: "webservices-integration"
title: "Integração com Web Services"
summary: "Construção de aplicações distribuídas consumindo APIs cloud."
tags:
  - "api"
  - "rest"
youtube_playlists: []
contributors: []
---

Explora REST, autenticação, consumo de APIs externas e uso de serviços backend como Firebase ou AWS Lambda.
