---
slug: "arquiteturas-distribuidas"
title: "Arquiteturas Distribuídas"
summary: "Regiões, zonas de disponibilidade e teorema CAP."
tags:
  - "cap"
  - "distribuicao"
youtube_playlists: []
contributors: []
---

Relaciona distribuição geográfica, tolerância a falhas, consistência e disponibilidade.
