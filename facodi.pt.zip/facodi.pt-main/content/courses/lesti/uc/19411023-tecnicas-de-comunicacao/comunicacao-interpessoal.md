---
slug: "comunicacao-interpessoal"
title: "Comunicação Interpessoal"
summary: "Dinâmica face a face e influência de estilos pessoais."
tags:
  - "interpessoal"
  - "linguagem"
youtube_playlists: []
contributors: []
---

Explora impacto de personalidade, linguagem verbal/não-verbal e adaptação da mensagem ao interlocutor.
