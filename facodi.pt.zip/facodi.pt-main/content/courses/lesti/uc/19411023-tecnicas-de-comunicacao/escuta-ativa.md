---
slug: "escuta-ativa"
title: "Escuta Ativa"
summary: "Técnicas para receber e compreender mensagens com qualidade."
tags:
  - "escuta"
  - "feedback"
youtube_playlists: []
contributors: []
---

Foca atenção plena, reformulação, perguntas de esclarecimento e superação de barreiras.
