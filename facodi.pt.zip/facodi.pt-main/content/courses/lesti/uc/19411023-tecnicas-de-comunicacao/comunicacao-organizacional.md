---
slug: "comunicacao-organizacional"
title: "Comunicação Organizacional"
summary: "Fluxos de comunicação em empresas e gestão de conflitos."
tags:
  - "organizacoes"
  - "lideranca"
youtube_playlists: []
contributors: []
---

Apresenta canais formais/informais, papel da liderança e técnicas de negociação e feedback construtivo.
