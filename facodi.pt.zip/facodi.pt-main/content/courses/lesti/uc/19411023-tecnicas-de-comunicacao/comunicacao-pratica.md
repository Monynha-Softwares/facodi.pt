---
slug: "comunicacao-pratica"
title: "Comunicação Prática"
summary: "Produção de textos e apresentações profissionais."
tags:
  - "apresentacoes"
  - "escrita"
youtube_playlists: []
contributors: []
---

Desenvolve redação de emails, relatórios, apresentações públicas e simulações de entrevistas também em inglês.
