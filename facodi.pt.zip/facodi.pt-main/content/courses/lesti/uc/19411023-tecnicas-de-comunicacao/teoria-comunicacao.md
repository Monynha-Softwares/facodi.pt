---
slug: "teoria-comunicacao"
title: "Teoria da Comunicação"
summary: "Modelos emissor-mensagem-receptor e funções da comunicação."
tags:
  - "comunicacao"
  - "modelos"
youtube_playlists: []
contributors: []
---

Analisa códigos, canais e contextos, abordando comunicação para informar, persuadir e entreter.
