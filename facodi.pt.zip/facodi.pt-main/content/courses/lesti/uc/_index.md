---
title: "Unidades Curriculares"
lead: "Componentes curriculares do plano LESTI 2025/2026 (obrigatórias e optativas)."
contributors: []
---
