---
slug: "sistemas-lineares-e-vetores-proprios"
title: "Sistemas Lineares e Vetores Próprios"
summary: "Solução de sistemas lineares, mudança de base e cálculo de autovalores e autovetores."
tags:
  - "sistemas-lineares"
  - "autovalores"
youtube_playlists: []
contributors: []
---

Apresenta métodos de resolução como regra de Cramer, discute estabilidade numérica e introduz diagonalização como ferramenta de simplificação de transformações lineares.
