---
slug: "calculo-vetorial-e-produtos"
title: "Cálculo Vetorial e Produtos"
summary: "Produtos interno, externo e misto e sua interpretação geométrica."
tags:
  - "produto-interno"
  - "gram-schmidt"
youtube_playlists: []
contributors: []
---

Analisa o papel do produto interno na medição de ângulos e comprimentos, introduz a ortogonalização de Gram-Schmidt e relaciona produtos externo e misto com áreas e volumes.
