---
slug: "geometria-analitica-basica"
title: "Geometria Analítica Básica"
summary: "Equações de retas e planos, parâmetros diretores e posições relativas."
tags:
  - "retas"
  - "planos"
youtube_playlists: []
contributors: []
---

Estuda representações paramétricas e implícitas de retas e planos, classificando interseções, paralelismo e ortogonalidade em ambientes tridimensionais.
