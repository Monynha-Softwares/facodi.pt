---
slug: "classe-e-objeto"
title: "Classe e Objeto"
summary: "Definição de classes, objetos, atributos e métodos."
tags:
  - "classe"
  - "objeto"
youtube_playlists: []
contributors: []
---

Explora identidade, estado e comportamento de objetos, incluindo criação e ciclo de vida de instâncias.
