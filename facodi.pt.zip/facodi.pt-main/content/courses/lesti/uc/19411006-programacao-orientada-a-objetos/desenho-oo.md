---
slug: "desenho-oo"
title: "Desenho OO"
summary: "Aplicação prática do paradigma em projetos com UML e implementação."
tags:
  - "uml"
  - "projetos"
youtube_playlists: []
contributors: []
---

Apresenta etapas de análise, desenho e codificação OO, com foco em pequenos projetos e padrões iniciais.
