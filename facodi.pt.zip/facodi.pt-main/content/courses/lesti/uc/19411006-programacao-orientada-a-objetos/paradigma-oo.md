---
slug: "paradigma-oo"
title: "Paradigma OO"
summary: "Motivação do paradigma orientado a objetos e comparação com abordagens procedurais."
tags:
  - "oo"
  - "paradigma"
youtube_playlists: []
contributors: []
---

Contextualiza surgimento da OO, vantagens de abstração e mapeamento direto para conceitos do domínio.
