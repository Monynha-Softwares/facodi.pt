---
slug: "heranca-e-polimorfismo"
title: "Herança e Polimorfismo"
summary: "Reutilização de código e polimorfismo de subtipo/sobrecarga."
tags:
  - "heranca"
  - "polimorfismo"
youtube_playlists: []
contributors: []
---

Ilustra hierarquias de classes, métodos virtuais, sobrescrita e uso de interfaces para promover flexibilidade.
