---
slug: "associacoes-entre-classes"
title: "Associações entre Classes"
summary: "Relações de associação, agregação e composição e seu impacto no design."
tags:
  - "associacoes"
  - "design"
youtube_playlists: []
contributors: []
---

Discute cardinalidade, ciclo de vida e princípios de baixo acoplamento e alta coesão.
