---
slug: "encapsulamento"
title: "Encapsulamento"
summary: "Ocultação de informação e definição de interfaces públicas."
tags:
  - "interfaces"
  - "abstracao"
youtube_playlists: []
contributors: []
---

Apresenta modificadores de acesso, imutabilidade e boas práticas para manter invariantes internos.
