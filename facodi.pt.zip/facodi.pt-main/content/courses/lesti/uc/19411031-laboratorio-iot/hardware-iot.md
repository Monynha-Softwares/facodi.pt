---
slug: "hardware-iot"
title: "Hardware IoT"
summary: "Plataformas de prototipagem e sensores/atuadores."
tags:
  - "hardware"
  - "sensores"
youtube_playlists: []
contributors: []
---

Apresenta ESP32, Arduino IoT, sensores ambientais e atuadores controlados eletronicamente.
