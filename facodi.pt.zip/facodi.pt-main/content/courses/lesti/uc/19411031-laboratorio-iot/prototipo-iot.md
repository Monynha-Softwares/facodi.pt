---
slug: "prototipo-iot"
title: "Protótipo IoT"
summary: "Projeto integrador com nós IoT, comunicação e aplicação."
tags:
  - "projeto"
  - "iot"
youtube_playlists: []
contributors: []
---

Planeia, implementa e testa uma solução IoT completa com recolha, transmissão e visualização de dados.
