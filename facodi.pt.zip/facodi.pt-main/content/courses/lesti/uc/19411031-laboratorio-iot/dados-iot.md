---
slug: "dados-iot"
title: "Dados em IoT"
summary: "Formatos leves, plataformas cloud e dashboards."
tags:
  - "dados"
  - "cloud"
youtube_playlists: []
contributors: []
---

Estuda JSON/BSON, ingestão em plataformas (AWS IoT, ThingsBoard) e visualização em tempo real.
