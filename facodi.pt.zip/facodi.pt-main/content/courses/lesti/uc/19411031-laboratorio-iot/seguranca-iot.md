---
slug: "seguranca-iot"
title: "Segurança IoT"
summary: "Riscos, autenticação e cifragem em dispositivos conectados."
tags:
  - "seguranca"
  - "iot"
youtube_playlists: []
contributors: []
---

Discute credenciais, TLS em MQTT, isolamento de redes e atualizações de firmware.
