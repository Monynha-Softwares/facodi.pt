---
slug: "fundamentos-iot"
title: "Fundamentos de IoT"
summary: "Conceitos e exemplos de aplicações da Internet das Coisas."
tags:
  - "iot"
  - "conceitos"
youtube_playlists: []
contributors: []
---

Explora cenários como casa inteligente, cidades inteligentes e monitorização industrial.
