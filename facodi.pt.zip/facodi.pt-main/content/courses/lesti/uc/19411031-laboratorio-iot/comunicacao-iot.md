---
slug: "comunicacao-iot"
title: "Comunicação IoT"
summary: "Protocolos sem fios e arquiteturas de comunicação para IoT."
tags:
  - "mqtt"
  - "wireless"
youtube_playlists: []
contributors: []
---

Compara BLE, ZigBee, LoRaWAN, MQTT e padrões cliente-servidor vs publish/subscribe.
