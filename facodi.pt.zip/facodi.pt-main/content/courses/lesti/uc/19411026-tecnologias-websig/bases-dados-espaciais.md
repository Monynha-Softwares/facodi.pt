---
slug: "bases-dados-espaciais"
title: "Bases de Dados Espaciais"
summary: "Tipos geométricos, consultas espaciais e extensões como PostGIS."
tags:
  - "bd"
  - "espacial"
youtube_playlists: []
contributors: []
---

Explica armazenamento de pontos, linhas e polígonos, índices espaciais e operações de proximidade.
