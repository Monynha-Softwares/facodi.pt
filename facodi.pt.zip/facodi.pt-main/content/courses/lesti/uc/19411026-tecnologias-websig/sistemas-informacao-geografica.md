---
slug: "sistemas-informacao-geografica"
title: "Sistemas de Informação Geográfica"
summary: "Representação de dados espaciais, projeções e uso de ferramentas SIG."
tags:
  - "sig"
  - "geoinformacao"
youtube_playlists: []
contributors: []
---

Analisa dados vetoriais/rasters, projeções como UTM e utilização de QGIS para visualização e análise.
