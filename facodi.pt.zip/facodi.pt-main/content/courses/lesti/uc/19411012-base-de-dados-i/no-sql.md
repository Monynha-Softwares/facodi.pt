---
slug: "no-sql"
title: "NoSQL"
summary: "Histórico, teorema CAP e categorias de bases não relacionais."
tags:
  - "nosql"
  - "cap"
youtube_playlists: []
contributors: []
---

Apresenta modelos documento, coluna, chave-valor e grafo, discutindo casos de uso e exemplos práticos.
