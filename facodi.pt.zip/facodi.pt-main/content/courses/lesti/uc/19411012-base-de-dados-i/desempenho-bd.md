---
slug: "desempenho-bd"
title: "Desempenho em BD"
summary: "Índices, planos de execução e estratégias de otimização."
tags:
  - "desempenho"
  - "indices"
youtube_playlists: []
contributors: []
---

Discute índices B-tree/hash, otimização de consultas, particionamento e dimensionamento vertical/horizontal.
