---
slug: "sgbd-conceitos"
title: "Conceitos de SGBD"
summary: "Finalidade, arquitetura e componentes de um SGBD."
tags:
  - "sgbd"
  - "arquitetura"
youtube_playlists: []
contributors: []
---

Analisa diferenças entre armazenamento em ficheiros e bases de dados e apresenta a arquitetura de três níveis.
