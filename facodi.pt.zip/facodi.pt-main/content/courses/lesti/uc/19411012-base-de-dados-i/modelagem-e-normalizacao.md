---
slug: "modelagem-e-normalizacao"
title: "Modelagem e Normalização"
summary: "Transformação de modelos ER e aplicação de formas normais."
tags:
  - "modelagem"
  - "normalizacao"
youtube_playlists: []
contributors: []
---

Revê formas normais, elimina redundâncias e discute regras de Codd para sistemas relacionais.
