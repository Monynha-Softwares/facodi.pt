---
slug: "bd-distribuidas"
title: "BD Distribuídas"
summary: "Replicação, fragmentação e integração de bases heterogéneas."
tags:
  - "distribuicao"
  - "replicacao"
youtube_playlists: []
contributors: []
---

Explora desafios de consistência e coordenação em cenários distribuídos e integrações multi-SGBD.
