---
slug: "sql-idioma"
title: "SQL"
summary: "Definição, manipulação e controlo de dados com SQL."
tags:
  - "sql"
  - "consultas"
youtube_playlists: []
contributors: []
---

Abrange DDL, DML e DCL, joins, subconsultas, agregações e controlo de permissões.
