---
slug: "transacoes"
title: "Transações"
summary: "Propriedades ACID e controlo de concorrência."
tags:
  - "acid"
  - "concorrencia"
youtube_playlists: []
contributors: []
---

Apresenta atomicidade, consistência, isolamento e durabilidade, e mecanismos de controlo de concorrência e recuperação.
