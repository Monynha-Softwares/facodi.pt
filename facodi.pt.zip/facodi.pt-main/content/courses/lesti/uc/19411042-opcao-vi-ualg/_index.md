---
title: "Opção VI UAlg/ISE"
code: "19411042"
description: "Optativa alternativa à UC de Cibersegurança dentro da pista de Ciências Informáticas."
ects: 5
semester: 5
language: "pt"
prerequisites: []
learning_outcomes:
  - "Selecionar UC optativa alinhada com interesses avançados em informática."
  - "Alcançar competências específicas previstas na unidade escolhida."
  - "Relacionar conteúdos optativos com os desafios profissionais pretendidos."
youtube_playlists: []
summary: "Oferece flexibilidade para escolher outras unidades informáticas avançadas conforme oferta institucional."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

## Conteúdos Programáticos

Variam de acordo com a unidade optativa escolhida dentro da oferta da UAlg/ISE, substituindo Cibersegurança quando apropriado.
