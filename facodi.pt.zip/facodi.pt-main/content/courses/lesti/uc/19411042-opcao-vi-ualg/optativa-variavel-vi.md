---
slug: "optativa-variavel-vi"
title: "Optativa Variável VI"
summary: "Conteúdos definidos pela UC selecionada."
tags:
  - "optativa"
  - "ci"
youtube_playlists: []
contributors: []
---

Podem incluir temas de computação avançada, inteligência de dados, linguagens ou outras áreas emergentes.
