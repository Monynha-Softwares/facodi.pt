---
slug: "cinematica-robot"
title: "Cinemática de Robôs"
summary: "Representação de posições e orientações e cálculo de trajetórias."
tags:
  - "cinematica"
  - "manipuladores"
youtube_playlists: []
contributors: []
---

Inclui matrizes de rotação, parâmetros Denavit-Hartenberg e movimentos para manipuladores simples.
