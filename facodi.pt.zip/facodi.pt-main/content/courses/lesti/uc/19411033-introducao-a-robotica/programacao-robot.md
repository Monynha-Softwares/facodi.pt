---
slug: "programacao-robot"
title: "Programação de Robôs"
summary: "Algoritmos de navegação básica e manipulação."
tags:
  - "programacao"
  - "robotica"
youtube_playlists: []
contributors: []
---

Inclui seguir linha, evitar obstáculos e sequências para manipulação de objetos.
