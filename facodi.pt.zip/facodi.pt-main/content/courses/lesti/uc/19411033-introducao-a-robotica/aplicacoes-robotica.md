---
slug: "aplicacoes-robotica"
title: "Aplicações da Robótica"
summary: "Áreas de aplicação e considerações éticas."
tags:
  - "aplicacoes"
  - "etica"
youtube_playlists: []
contributors: []
---

Explora robótica industrial, médica, espacial e impactos sociais da automação.
