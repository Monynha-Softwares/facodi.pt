---
slug: "sensores-atuadores"
title: "Sensores e Atuadores"
summary: "Tipos comuns usados em robótica e sua interface com controladores."
tags:
  - "sensores"
  - "atuadores"
youtube_playlists: []
contributors: []
---

Apresenta sensores ultrassónicos, infravermelhos, giroscópios e atuadores como servomotores e motores DC.
