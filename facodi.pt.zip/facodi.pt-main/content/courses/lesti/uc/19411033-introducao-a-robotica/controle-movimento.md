---
slug: "controle-movimento"
title: "Controlo de Movimento"
summary: "Conceitos de controlo em malha fechada e PID básico."
tags:
  - "controle"
  - "pid"
youtube_playlists: []
contributors: []
---

Mostra como ajustar controladores para manter velocidade/posição usando feedback sensorial.
