---
slug: "plataforma-robotica"
title: "Plataformas Robóticas"
summary: "Utilização de Arduino, ROS e kits robóticos."
tags:
  - "ros"
  - "arduino"
youtube_playlists: []
contributors: []
---

Discute arquitetura de nodes e topics no ROS e programação de robôs móveis com microcontroladores.
