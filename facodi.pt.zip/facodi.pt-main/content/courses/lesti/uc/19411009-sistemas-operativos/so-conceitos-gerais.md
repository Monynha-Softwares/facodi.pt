---
slug: "so-conceitos-gerais"
title: "Conceitos Gerais de SO"
summary: "Estrutura e serviços fundamentais de um sistema operativo."
tags:
  - "kernel"
  - "servicos"
youtube_playlists: []
contributors: []
---

Aborda camadas, modos de operação, chamadas de sistema e função do kernel na mediação entre hardware e aplicações.
