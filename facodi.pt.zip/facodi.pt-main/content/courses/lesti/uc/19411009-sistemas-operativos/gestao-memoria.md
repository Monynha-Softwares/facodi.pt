---
slug: "gestao-memoria"
title: "Gestão de Memória"
summary: "Técnicas de alocação, paginação, segmentação e memória virtual."
tags:
  - "memoria"
  - "paginacao"
youtube_playlists: []
contributors: []
---

Analisa utilização de memória principal, algoritmos de substituição de páginas e impacto da paginação por demanda.
