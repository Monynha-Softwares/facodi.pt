---
slug: "scripting-e-automacao"
title: "Scripting e Automação"
summary: "Uso de Bash e PowerShell para automatizar tarefas."
tags:
  - "bash"
  - "powershell"
youtube_playlists: []
contributors: []
---

Ensina escrita de scripts para gerir ficheiros, processos e configurações repetitivas, explorando loops, variáveis e módulos.
