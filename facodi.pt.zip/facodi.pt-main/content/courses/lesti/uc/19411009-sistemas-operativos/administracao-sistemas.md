---
slug: "administracao-sistemas"
title: "Administração de Sistemas"
summary: "Instalação e configuração de Windows e Linux em contexto desktop e servidor."
tags:
  - "windows"
  - "linux"
youtube_playlists: []
contributors: []
---

Cobre gestão de utilizadores, configuração de serviços básicos, partilha de recursos e noções de Windows Server (quotas, AD, políticas).
