---
slug: "processos-e-threads"
title: "Processos e Threads"
summary: "Criação, estados, escalonamento e sincronização de processos e threads."
tags:
  - "processos"
  - "concorrencia"
youtube_playlists: []
contributors: []
---

Estuda políticas de escalonamento, mecanismos de sincronização (mutexes, semáforos) e estratégias para evitar e tratar deadlocks.
