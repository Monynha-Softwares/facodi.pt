---
slug: "protecao-seguranca-so"
title: "Proteção e Segurança"
summary: "Mecanismos de proteção, autenticação e permissões em sistemas operativos."
tags:
  - "seguranca"
  - "permissoes"
youtube_playlists: []
contributors: []
---

Introduz separação de modos, listas de controlo de acesso, autenticação, firewall básica e boas práticas de segurança em ambientes multiutilizador.
