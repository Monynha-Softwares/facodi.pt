---
slug: "sistemas-arquivos-io"
title: "Sistemas de Ficheiros e I/O"
summary: "Organização de ficheiros, diretórios e gestão de dispositivos de E/S."
tags:
  - "ficheiros"
  - "io"
youtube_playlists: []
contributors: []
---

Descreve chamadas de sistema para ficheiros, estrutura de sistemas FAT/NTFS/ext e mecanismos de drivers e buffers de I/O.
