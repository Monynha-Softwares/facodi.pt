---
slug: "validacao-e-metricas"
title: "Validação e Métricas"
summary: "Avaliação de modelos com validação cruzada e métricas apropriadas."
tags:
  - "avaliacao"
  - "metricas"
youtube_playlists: []
contributors: []
---

Detalha divisão treino/teste, k-fold, grid search, matriz de confusão, precisão, recall, F1, ROC/AUC e métricas de regressão.
