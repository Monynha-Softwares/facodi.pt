---
slug: "algoritmos-nao-supervisionados"
title: "Algoritmos Não Supervisionados"
summary: "Clusterização, redução de dimensionalidade e deteção de anomalias."
tags:
  - "clusterizacao"
  - "pca"
youtube_playlists: []
contributors: []
---

Analisa k-means, DBSCAN, PCA, autoencoders e técnicas para identificar outliers.
