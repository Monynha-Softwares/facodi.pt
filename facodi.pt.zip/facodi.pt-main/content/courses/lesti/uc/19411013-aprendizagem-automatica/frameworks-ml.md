---
slug: "frameworks-ml"
title: "Frameworks de ML"
summary: "Ferramentas e plataformas para desenvolvimento de modelos."
tags:
  - "scikit-learn"
  - "ferramentas"
youtube_playlists: []
contributors: []
---

Explora bibliotecas como scikit-learn, TensorFlow/Keras e ambientes como Google Colab ou WEKA.
