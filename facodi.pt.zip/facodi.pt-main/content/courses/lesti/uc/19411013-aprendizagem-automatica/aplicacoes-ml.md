---
slug: "aplicacoes-ml"
title: "Aplicações de ML"
summary: "Casos de uso de ML em problemas reais."
tags:
  - "aplicacoes"
  - "casos"
youtube_playlists: []
contributors: []
---

Explora exemplos como deteção de spam, previsão de séries, reconhecimento de padrões e recomendações.
