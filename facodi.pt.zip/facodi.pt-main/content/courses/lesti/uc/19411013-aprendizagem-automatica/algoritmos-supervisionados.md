---
slug: "algoritmos-supervisionados"
title: "Algoritmos Supervisionados"
summary: "Classificação e regressão com métodos clássicos."
tags:
  - "classificacao"
  - "regressao"
youtube_playlists: []
contributors: []
---

Cobre k-NN, regressões linear e logística, árvores de decisão, ensembles, SVM e redes neurais simples.
