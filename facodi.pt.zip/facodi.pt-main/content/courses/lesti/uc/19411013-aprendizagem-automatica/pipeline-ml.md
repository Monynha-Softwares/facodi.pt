---
slug: "pipeline-ml"
title: "Pipelines de ML"
summary: "Construção de fluxos completos de machine learning."
tags:
  - "pipeline"
  - "automacao"
youtube_playlists: []
contributors: []
---

Integra pré-processamento, treino, avaliação e implementação, utilizando pipelines automatizados em frameworks como scikit-learn.
