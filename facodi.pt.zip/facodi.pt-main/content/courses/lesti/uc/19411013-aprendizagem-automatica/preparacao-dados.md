---
slug: "preparacao-dados"
title: "Preparação de Dados"
summary: "Engenharia de atributos, limpeza e transformação de dados."
tags:
  - "dados"
  - "features"
youtube_playlists: []
contributors: []
---

Discute normalização, encoding, seleção e criação de características relevantes ao modelo.
