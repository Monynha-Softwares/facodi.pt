---
slug: "ml-fundamentos"
title: "Fundamentos de ML"
summary: "Conceitos básicos, paradigmas e desafios como overfitting."
tags:
  - "ml"
  - "fundamentos"
youtube_playlists: []
contributors: []
---

Introduz terminologia, diferenças entre aprendizagem supervisionada, não supervisionada e reforço e discute generalização.
