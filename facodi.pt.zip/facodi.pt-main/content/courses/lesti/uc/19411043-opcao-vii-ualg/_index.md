---
title: "Opção VII UAlg/ISE"
code: "19411043"
description: "Optativa adicional disponível para estudantes que não escolham Low-Code ou Robótica, conforme oferta institucional."
ects: 5
semester: 5
language: "pt"
prerequisites: []
learning_outcomes:
  - "Personalizar percurso académico com unidade optativa relevante."
  - "Completar objetivos pedagógicos definidos pela unidade selecionada."
  - "Relacionar aprendizagens optativas com metas profissionais ou académicas."
youtube_playlists: []
summary: "Permite seleção de outras disciplinas de 5 ECTS alinhadas a interesses individuais, abertas a todas as pistas."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

## Conteúdos Programáticos

Variam conforme a unidade optativa escolhida, permitindo alternativas a Low-Code e Introdução à Robótica.
