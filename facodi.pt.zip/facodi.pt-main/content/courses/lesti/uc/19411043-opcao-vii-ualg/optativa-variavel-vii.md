---
slug: "optativa-variavel-vii"
title: "Optativa Variável VII"
summary: "Conteúdos determinados pela UC optativa selecionada."
tags:
  - "optativa"
  - "livre"
youtube_playlists: []
contributors: []
---

Pode envolver tópicos emergentes em tecnologia, gestão, línguas ou outras áreas de interesse.
