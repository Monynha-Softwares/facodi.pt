---
slug: "gestao-de-projetos"
title: "Gestão de Projetos"
summary: "Planeamento e acompanhamento de tarefas com software de gestão de projetos."
tags:
  - "projetos"
  - "planeamento"
youtube_playlists: []
contributors: []
---

Apresenta ferramentas como Trello ou Jira, definição de backlog, milestones e acompanhamento de recursos e riscos.
