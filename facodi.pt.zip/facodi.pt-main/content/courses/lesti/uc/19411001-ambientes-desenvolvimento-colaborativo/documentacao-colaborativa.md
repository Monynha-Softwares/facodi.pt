---
slug: "documentacao-colaborativa"
title: "Documentação Colaborativa"
summary: "Uso de wikis e markdown para manter informação do projeto sempre atualizada."
tags:
  - "documentacao"
  - "wiki"
youtube_playlists: []
contributors: []
---

Mostra como organizar páginas, padronizar templates e incentivar contribuições de toda a equipa.
