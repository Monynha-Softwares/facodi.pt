---
slug: "controlo-de-versao"
title: "Controlo de Versão"
summary: "Fluxos com Git, repositórios remotos e práticas de branching."
tags:
  - "git"
  - "versionamento"
youtube_playlists: []
contributors: []
---

Detalha commits, branches, merges, pull requests e políticas para revisão de código em equipas distribuídas.
