---
slug: "documentacao-codigo"
title: "Documentação de Código"
summary: "Boas práticas e ferramentas para gerar documentação a partir do código."
tags:
  - "docstring"
  - "ferramentas"
youtube_playlists: []
contributors: []
---

Introduz comentários autoexplicativos, padrões de documentação e ferramentas como Sphinx ou Javadoc.
