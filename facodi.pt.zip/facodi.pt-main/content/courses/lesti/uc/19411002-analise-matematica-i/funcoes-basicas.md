---
slug: "funcoes-basicas"
title: "Funções Básicas"
summary: "Funções elementares, composição, inversa e parametrização."
tags:
  - "funcoes"
  - "transcendentes"
youtube_playlists: []
contributors: []
---

Estuda funções polinomiais, exponenciais, logarítmicas e trigonométricas, bem como transformações por composição, inversão, formulação implícita e parametrizações.
