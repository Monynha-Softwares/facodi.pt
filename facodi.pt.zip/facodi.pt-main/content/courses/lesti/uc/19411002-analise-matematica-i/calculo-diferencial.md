---
slug: "calculo-diferencial"
title: "Cálculo Diferencial"
summary: "Limites, derivadas, séries de Taylor e otimização."
tags:
  - "derivadas"
  - "limites"
youtube_playlists: []
contributors: []
---

Introduz técnicas de cálculo de limites, regras de derivação, aplicações a taxas de variação e problemas de otimização, incluindo uso de séries de Taylor para aproximações.
