---
slug: "numeros-reais"
title: "Números Reais"
summary: "Revisão dos conjuntos numéricos e propriedades fundamentais dos reais."
tags:
  - "numeros"
  - "intervalos"
youtube_playlists: []
contributors: []
---

Aborda hierarquia N, Z, Q e R, operações fundamentais, intervalos, limites superior/inferior e noções de completude necessárias à análise.
