---
slug: "calculo-integral"
title: "Cálculo Integral"
summary: "Integrais indefinidas e definidas e suas aplicações geométricas."
tags:
  - "integrais"
  - "areas"
youtube_playlists: []
contributors: []
---

Apresenta técnicas de integração e aplicações a áreas planas, comprimentos de curva e volumes gerados por rotação, destacando interpretação física das integrais.
