---
slug: "apresentacao-publica"
title: "Apresentação Pública"
summary: "Preparação e defesa do projeto perante banca avaliadora."
tags:
  - "apresentacao"
  - "defesa"
youtube_playlists: []
contributors: []
---

Organiza apresentação oral, demonstra protótipos e responde a questões técnicas.
