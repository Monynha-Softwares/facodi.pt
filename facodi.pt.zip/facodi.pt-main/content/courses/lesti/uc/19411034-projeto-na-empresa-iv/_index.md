---
title: "Projeto na Empresa IV"
code: "19411034"
description: "Projeto empresarial avançado, continuidade ou novo desafio de maior escopo preparando para o trabalho final."
ects: 5
semester: 5
language: "pt"
prerequisites: []
learning_outcomes:
  - "Gerir projetos tecnológicos mais complexos em parceria com empresas ou centros de I&D."
  - "Integrar múltiplos sistemas ou componentes cumprindo requisitos de qualidade e prazo."
  - "Elaborar relatório abrangente e defender publicamente resultados e contributos."
youtube_playlists: []
summary: "Aprofunda experiência profissional com projetos de maior complexidade, documentação e apresentação públicas."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

## Conteúdos Programáticos

Definidos pelo projeto acordado com a entidade parceira, envolvendo análise aprofundada, metodologia, desenvolvimento, integração, testes, relatório detalhado e defesa pública.
