---
slug: "metodologia-trabalho"
title: "Metodologia de Trabalho"
summary: "Seleção de metodologia (ágil, cascata ou experimental) e planeamento."
tags:
  - "metodologia"
  - "planeamento"
youtube_playlists: []
contributors: []
---

Define cadências de acompanhamento, métricas e ferramentas de colaboração.
