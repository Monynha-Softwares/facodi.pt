---
slug: "definicao-projeto"
title: "Definição do Projeto"
summary: "Análise detalhada do problema e requisitos com stakeholders."
tags:
  - "requisitos"
  - "escopo"
youtube_playlists: []
contributors: []
---

Inclui levantamento aprofundado, acordos de escopo e critérios de sucesso.
