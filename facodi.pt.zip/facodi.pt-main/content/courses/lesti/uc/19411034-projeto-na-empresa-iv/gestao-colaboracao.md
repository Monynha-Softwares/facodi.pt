---
slug: "gestao-colaboracao"
title: "Gestão e Colaboração"
summary: "Trabalho em equipa com profissionais da empresa/parceiro."
tags:
  - "colaboracao"
  - "gestao"
youtube_playlists: []
contributors: []
---

Inclui comunicação regular, gestão de tempo, resolução de conflitos e adaptação a mudanças.
