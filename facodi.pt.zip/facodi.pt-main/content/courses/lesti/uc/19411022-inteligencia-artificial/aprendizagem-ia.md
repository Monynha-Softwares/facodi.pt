---
slug: "aprendizagem-ia"
title: "Aprendizagem na IA"
summary: "Resumo de aprendizagem supervisionada, não supervisionada e por reforço."
tags:
  - "ml"
  - "ia"
youtube_playlists: []
contributors: []
---

Reforça conceitos de ML e introduz redes neurais e aprendizagem por reforço no contexto da IA.
