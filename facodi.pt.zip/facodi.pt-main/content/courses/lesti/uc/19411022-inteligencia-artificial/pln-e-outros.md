---
slug: "pln-e-outros"
title: "PLN e Outras Aplicações"
summary: "Visão geral de PLN, visão computacional e ética da IA."
tags:
  - "pln"
  - "visao"
youtube_playlists: []
contributors: []
---

Explora tokenização, modelos modernos, impacto social e desafios éticos da IA em diferentes domínios.
