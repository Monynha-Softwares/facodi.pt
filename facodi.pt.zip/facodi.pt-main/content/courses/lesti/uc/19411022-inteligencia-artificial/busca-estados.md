---
slug: "busca-estados"
title: "Busca em Espaços de Estados"
summary: "BFS, DFS, busca heurística e algoritmo A*."
tags:
  - "busca"
  - "heuristica"
youtube_playlists: []
contributors: []
---

Estuda representações de estados, grafos de procura, propriedades de completude e optimalidade.
