---
slug: "sistema-inteligente-proj"
title: "Projeto de Sistema Inteligente"
summary: "Implementação prática de uma técnica de IA."
tags:
  - "projeto"
  - "ia"
youtube_playlists: []
contributors: []
---

Propõe desenvolver agente de jogo, sistema especialista ou solver heurístico, avaliando desempenho.
