---
slug: "planeamento"
title: "Planeamento"
summary: "Planeamento de ações, pré-condições e efeitos."
tags:
  - "planeamento"
  - "acoes"
youtube_playlists: []
contributors: []
---

Discute algoritmos de planeamento clássico e hierárquico para alcançar metas em ambientes determinísticos.
