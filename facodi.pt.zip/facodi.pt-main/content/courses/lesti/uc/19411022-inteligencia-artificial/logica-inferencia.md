---
slug: "logica-inferencia"
title: "Lógica e Inferência"
summary: "Lógica proposicional/predicados, resolução e encadeamento."
tags:
  - "logica"
  - "inferência"
youtube_playlists: []
contributors: []
---

Apresenta formalismos lógicos e mecanismos de inferência para sistemas baseados em regras.
