---
slug: "documentacao-relatorio"
title: "Documentação e Relatório"
summary: "Registo contínuo do trabalho e elaboração de relatório final."
tags:
  - "documentacao"
  - "relatorio"
youtube_playlists: []
contributors: []
---

Inclui documentação técnica, relatórios de progresso e relatório final conforme normas institucionais.
