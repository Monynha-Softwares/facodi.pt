---
slug: "apresentacao-defesa"
title: "Apresentação e Defesa"
summary: "Preparação e apresentação oral do projeto perante avaliadores."
tags:
  - "apresentacao"
  - "defesa"
youtube_playlists: []
contributors: []
---

Abrange criação de materiais de apoio, demonstração da solução e resposta a perguntas técnicas.
