---
slug: "planeamento-projeto"
title: "Planeamento do Projeto"
summary: "Organização de tarefas, cronograma e recursos para execução do projeto."
tags:
  - "planeamento"
  - "projeto"
youtube_playlists: []
contributors: []
---

Elabora planos de trabalho, define marcos e gere riscos com acompanhamento periódico.
