---
slug: "ferramentas-tecnologias"
title: "Ferramentas e Tecnologias"
summary: "Uso de tecnologias específicas requeridas pelo projeto."
tags:
  - "tecnologias"
  - "aprendizagem"
youtube_playlists: []
contributors: []
---

Pode envolver novas linguagens, frameworks, plataformas de hardware ou ferramentas de gestão.
