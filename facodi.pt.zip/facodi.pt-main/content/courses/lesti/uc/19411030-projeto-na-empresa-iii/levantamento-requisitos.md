---
slug: "levantamento-requisitos"
title: "Levantamento de Requisitos"
summary: "Identificação de necessidades do parceiro e definição de objetivos do projeto."
tags:
  - "requisitos"
  - "analise"
youtube_playlists: []
contributors: []
---

Inclui reuniões iniciais, análise de contexto e documentação das expectativas e restrições.
