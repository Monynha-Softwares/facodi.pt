---
slug: "arduino-e-atmega"
title: "Arduino e ATmega"
summary: "Plataforma Arduino, arquitetura ATmega328 e periféricos."
tags:
  - "arduino"
  - "atmega"
youtube_playlists: []
contributors: []
---

Explora GPIO, temporizadores, ADC e interfaces de comunicação como UART, I2C e SPI.
