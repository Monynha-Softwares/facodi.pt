---
slug: "vlsi-e-estados"
title: "VLSI e Máquinas de Estados"
summary: "Circuitos integrados de grande escala e modelação do CPU como máquina de estados."
tags:
  - "vlsi"
  - "maquinas-de-estado"
youtube_playlists: []
contributors: []
---

Aborda evolução dos dispositivos VLSI e uso de diagramas de estados para descrever ciclos de instrução.
