---
slug: "projeto-embebido"
title: "Projeto Embebido"
summary: "Desenvolvimento e depuração de aplicações em microcontroladores."
tags:
  - "projeto"
  - "microcontrolador"
youtube_playlists: []
contributors: []
---

Propõe implementação de sistemas completos com leitura de sensores, atuação e comunicação, incluindo boas práticas de teste.
