---
slug: "introducao-embebidos"
title: "Introdução a Sistemas Embebidos"
summary: "Componentes e restrições de sistemas embebidos."
tags:
  - "embebidos"
  - "tempo-real"
youtube_playlists: []
contributors: []
---

Identifica sensores, atuadores, necessidades de tempo real e limitações de energia e memória.
