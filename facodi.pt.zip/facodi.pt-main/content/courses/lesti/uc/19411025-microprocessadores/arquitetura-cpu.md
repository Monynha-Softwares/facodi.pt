---
slug: "arquitetura-cpu"
title: "Arquitetura de CPU"
summary: "Componentes internos, conjuntos de instruções e arquiteturas RISC/CISC."
tags:
  - "cpu"
  - "arquitetura"
youtube_playlists: []
contributors: []
---

Analisa UC, ULA, registos, barramentos e diferenças entre arquiteturas Von Neumann e Harvard.
