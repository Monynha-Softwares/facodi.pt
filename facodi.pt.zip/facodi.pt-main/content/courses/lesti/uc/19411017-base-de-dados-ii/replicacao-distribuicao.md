---
slug: "replicacao-distribuicao"
title: "Replicação e Distribuição"
summary: "Replicação síncrona/assíncrona, sharding e consistência."
tags:
  - "replicacao"
  - "sharding"
youtube_playlists: []
contributors: []
---

Compara topologias de replicação, latência e trade-offs CAP em ambientes distribuídos.
