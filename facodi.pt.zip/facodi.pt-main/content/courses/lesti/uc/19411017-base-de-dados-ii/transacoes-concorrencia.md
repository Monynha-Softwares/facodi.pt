---
slug: "transacoes-concorrencia"
title: "Transações e Concorrência"
summary: "Isolamento, bloqueios, MVCC e tratamento de deadlocks."
tags:
  - "transacoes"
  - "concorrencia"
youtube_playlists: []
contributors: []
---

Explica níveis de isolamento, bloqueios de linhas/páginas, controlo por múltiplas versões e gestão de deadlocks.
