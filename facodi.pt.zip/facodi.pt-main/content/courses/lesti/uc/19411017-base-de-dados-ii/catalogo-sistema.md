---
slug: "catalogo-sistema"
title: "Catálogo do Sistema"
summary: "Dicionário de dados, views, triggers e programação armazenada."
tags:
  - "catalogo"
  - "plsql"
youtube_playlists: []
contributors: []
---

Analisa metadados, diferenças entre tabelas e views, uso de materialized views, triggers e packages.
