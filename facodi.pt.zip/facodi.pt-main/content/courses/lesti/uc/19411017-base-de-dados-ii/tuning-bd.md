---
slug: "tuning-bd"
title: "Tuning de BD"
summary: "Particionamento, processamento paralelo e monitorização de desempenho."
tags:
  - "tuning"
  - "paralelismo"
youtube_playlists: []
contributors: []
---

Discute estatísticas, identificação de bottlenecks, ajuste de parâmetros e uso de paralelismo para cargas intensivas.
