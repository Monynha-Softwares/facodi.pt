---
slug: "sql-avancado"
title: "SQL Avançado"
summary: "Consultas complexas, CTE, índices e planos de execução."
tags:
  - "sql"
  - "otimizacao"
youtube_playlists: []
contributors: []
---

Apresenta joins múltiplos, subconsultas correlacionadas, expressões hierárquicas e interpretação de planos para otimização.
