---
slug: "backup-recuperacao"
title: "Backup e Recuperação"
summary: "Estratégias de backup, logs e recuperação de desastres."
tags:
  - "backup"
  - "recuperacao"
youtube_playlists: []
contributors: []
---

Aborda backups completos, incrementais, uso de redo/undo logs e planos de recuperação de desastres.
