---
slug: "seguranca-bd"
title: "Segurança em BD"
summary: "Autenticação, permissões, auditoria e encriptação."
tags:
  - "seguranca"
  - "encriptacao"
youtube_playlists: []
contributors: []
---

Define políticas de segurança, gestão de utilizadores/roles, auditoria e cifragem de dados em repouso e trânsito.
