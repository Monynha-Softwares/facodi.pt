---
slug: "uml-estados-atividades"
title: "UML Estados e Atividades"
summary: "Diagrama de estados e atividades para comportamentos complexos."
tags:
  - "uml"
  - "comportamento"
youtube_playlists: []
contributors: []
---

Mostra representação de ciclos de vida de objetos e fluxos de trabalho com paralelismo e sincronização.
