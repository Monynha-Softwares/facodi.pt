---
slug: "processo-software"
title: "Processos de Software"
summary: "Modelos de ciclo de vida e seleção conforme contexto."
tags:
  - "processos"
  - "ciclo-de-vida"
youtube_playlists: []
contributors: []
---

Analisa cascata, espiral, incremental e métodos ágeis, destacando entregáveis e gestão de riscos.
