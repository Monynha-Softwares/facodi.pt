---
slug: "gestao-projeto-sw"
title: "Gestão de Projeto de Software"
summary: "Comparação entre PMBOK e Scrum e suporte por CI/CD."
tags:
  - "gestao"
  - "ci"
youtube_playlists: []
contributors: []
---

Cobre WBS, cronogramas, burndown charts, gestão de backlog e automação de builds e testes.
