---
slug: "uml-componentes"
title: "UML Componentes e Implantação"
summary: "Arquitetura de alto nível com diagramas de componentes e deployment."
tags:
  - "arquitetura"
  - "uml"
youtube_playlists: []
contributors: []
---

Representa módulos, interfaces e distribuição em nós físicos, como cliente-servidor.
