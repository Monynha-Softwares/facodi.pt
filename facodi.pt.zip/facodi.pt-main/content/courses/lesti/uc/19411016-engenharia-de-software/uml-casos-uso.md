---
slug: "uml-casos-uso"
title: "UML Casos de Uso"
summary: "Representação de requisitos funcionais com atores e cenários."
tags:
  - "uml"
  - "requisitos"
youtube_playlists: []
contributors: []
---

Detalha diagramas de casos de uso, documentação textual e relações include/extend.
