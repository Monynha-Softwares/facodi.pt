---
slug: "ferramentas-case"
title: "Ferramentas CASE"
summary: "Uso de ferramentas para modelagem e geração de código."
tags:
  - "case"
  - "ferramentas"
youtube_playlists: []
contributors: []
---

Explora StarUML, Enterprise Architect e integração com repositórios e pipelines de CI.
