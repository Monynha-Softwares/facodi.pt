---
slug: "analise-estruturada-vs-oo"
title: "Análise Estruturada vs OO"
summary: "Comparação entre abordagens centradas em dados/fluxos e orientadas a objetos."
tags:
  - "analise"
  - "oo"
youtube_playlists: []
contributors: []
---

Explora DFDs, diagramas de estrutura vs. modelos OO baseados em classes e objetos.
