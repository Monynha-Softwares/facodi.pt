---
slug: "uml-classes-sequencias"
title: "UML Classes e Sequências"
summary: "Modelação estrutural e comportamental em UML."
tags:
  - "uml"
  - "modelacao"
youtube_playlists: []
contributors: []
---

Aborda diagramas de classes com atributos/métodos e diagramas de sequência para interação temporal.
