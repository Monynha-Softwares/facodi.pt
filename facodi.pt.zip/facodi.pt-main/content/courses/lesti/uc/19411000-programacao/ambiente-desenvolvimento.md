---
slug: "ambiente-desenvolvimento"
title: "Ambiente de Desenvolvimento"
summary: "Configuração de IDEs, ferramentas e fluxo de trabalho em Python."
tags:
  - "ide"
  - "workflow"
youtube_playlists: []
contributors: []
---

Apresenta instalação, uso de editores/IDEs, execução de scripts e utilização do REPL para experimentação rápida.
