---
slug: "variaveis-tipos"
title: "Variáveis e Tipos"
summary: "Declaração de variáveis, tipos primitivos e operações básicas."
tags:
  - "tipos"
  - "python"
youtube_playlists: []
contributors: []
---

Explora números, booleanos e coleções, bem como conversões de tipo e boas práticas de nomeação.
