---
slug: "strings"
title: "Strings"
summary: "Manipulação de sequências de caracteres e operações de texto."
tags:
  - "texto"
  - "processamento"
youtube_playlists: []
contributors: []
---

Inclui fatiamento, busca de padrões, métodos da classe `str` e formatação avançada.
