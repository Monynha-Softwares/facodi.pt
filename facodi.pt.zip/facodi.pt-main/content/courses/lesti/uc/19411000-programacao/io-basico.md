---
slug: "io-basico"
title: "Entrada e Saída Básicas"
summary: "Leitura do teclado, escrita no ecrã e formatação de saída."
tags:
  - "io"
  - "strings"
youtube_playlists: []
contributors: []
---

Trabalha funções `input()` e `print()`, formatação com f-strings e tratamento de dados fornecidos pelo utilizador.
