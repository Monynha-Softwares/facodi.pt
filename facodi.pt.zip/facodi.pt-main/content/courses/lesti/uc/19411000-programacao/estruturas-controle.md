---
slug: "estruturas-controle"
title: "Estruturas de Controlo"
summary: "Instruções condicionais e laços de repetição."
tags:
  - "condicoes"
  - "loops"
youtube_playlists: []
contributors: []
---

Detalha `if/elif/else`, `match`, ciclos `for`, `while` e padrões de iteração para percorrer coleções.
