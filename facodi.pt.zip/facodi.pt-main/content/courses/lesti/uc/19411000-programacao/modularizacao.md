---
slug: "modularizacao"
title: "Modularização"
summary: "Definição e utilização de funções e procedimentos."
tags:
  - "funcoes"
  - "escopo"
youtube_playlists: []
contributors: []
---

Apresenta parâmetros, valores de retorno, escopo e documentação de funções para promover reutilização.
