---
slug: "fundamentos-programacao"
title: "Fundamentos de Programação"
summary: "Conceitos iniciais de algoritmia e lógica de programação."
tags:
  - "algoritmos"
  - "logica"
youtube_playlists: []
contributors: []
---

Mostra como decompor problemas em passos lógicos, construir pseudocódigo e compreender a importância da depuração.
