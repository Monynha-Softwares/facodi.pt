---
slug: "estruturas-dados-simples"
title: "Estruturas de Dados Simples"
summary: "Listas, tuplos, dicionários e operações básicas."
tags:
  - "listas"
  - "dicionarios"
youtube_playlists: []
contributors: []
---

Mostra criação, iteração e manipulação dessas estruturas, incluindo compreensão de listas e operações com dicionários.
