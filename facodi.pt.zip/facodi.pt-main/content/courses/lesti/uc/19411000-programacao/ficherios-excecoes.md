---
slug: "ficherios-excecoes"
title: "Ficheiros e Exceções"
summary: "Operações de I/O em ficheiros e tratamento de erros em Python."
tags:
  - "ficheiros"
  - "excecoes"
youtube_playlists: []
contributors: []
---

Explica abertura, leitura/escrita e encerramento de ficheiros, além de blocos `try/except` para garantir robustez.
