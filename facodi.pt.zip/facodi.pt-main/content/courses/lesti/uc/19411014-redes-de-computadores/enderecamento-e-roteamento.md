---
slug: "enderecamento-e-roteamento"
title: "Endereçamento e Roteamento"
summary: "IPv4/IPv6, ARP, ICMP e roteamento básico."
tags:
  - "ipv4"
  - "roteamento"
youtube_playlists: []
contributors: []
---

Descreve subnetting, tabelas de roteamento, rotas estáticas e protocolos auxiliares para diagnóstico e resolução de endereços.
