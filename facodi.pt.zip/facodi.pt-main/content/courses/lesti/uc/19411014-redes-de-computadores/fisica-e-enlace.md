---
slug: "fisica-e-enlace"
title: "Camadas Física e de Enlace"
summary: "Sinalização, modulação, enquadramento e controlo de erros."
tags:
  - "fisica"
  - "enlace"
youtube_playlists: []
contributors: []
---

Trata limites de Shannon, codificação de linha, CRC, protocolos ARQ e controlo de fluxo por janela deslizante.
