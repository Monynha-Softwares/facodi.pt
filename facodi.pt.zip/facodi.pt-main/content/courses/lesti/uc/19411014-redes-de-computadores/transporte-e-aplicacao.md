---
slug: "transporte-e-aplicacao"
title: "Camadas de Transporte e Aplicação"
summary: "Características de TCP/UDP e uso de portas."
tags:
  - "tcp"
  - "udp"
youtube_playlists: []
contributors: []
---

Analisa handshake TCP, controlo de congestionamento, diferenças para UDP e adequação a aplicações específicas.
