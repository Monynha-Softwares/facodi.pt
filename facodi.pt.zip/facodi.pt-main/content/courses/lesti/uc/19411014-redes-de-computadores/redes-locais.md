---
slug: "redes-locais"
title: "Redes Locais"
summary: "Ethernet, Wi-Fi e projeto de LANs com switches e APs."
tags:
  - "lan"
  - "ethernet"
youtube_playlists: []
contributors: []
---

Explica CSMA/CD e CSMA/CA, configurações básicas de switches e roteadores e planeamento de cablagem estruturada.
