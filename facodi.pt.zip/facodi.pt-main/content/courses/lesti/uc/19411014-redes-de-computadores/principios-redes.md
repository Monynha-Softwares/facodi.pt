---
slug: "principios-redes"
title: "Princípios de Redes"
summary: "Componentes, meios físicos e modelos de referência para redes de computadores."
tags:
  - "osi"
  - "tcp-ip"
youtube_playlists: []
contributors: []
---

Apresenta topologias, normas IEEE, e introduz o modelo OSI e TCP/IP relacionando-os a camadas e serviços.
