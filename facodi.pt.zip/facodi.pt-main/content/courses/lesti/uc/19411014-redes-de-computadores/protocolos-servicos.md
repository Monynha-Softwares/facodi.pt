---
slug: "protocolos-servicos"
title: "Protocolos e Serviços"
summary: "Operação de protocolos de aplicação como HTTP, FTP, SMTP e DNS."
tags:
  - "http"
  - "dns"
youtube_playlists: []
contributors: []
---

Relata ciclo de vida das comunicações cliente-servidor e integrações com camadas inferiores.
