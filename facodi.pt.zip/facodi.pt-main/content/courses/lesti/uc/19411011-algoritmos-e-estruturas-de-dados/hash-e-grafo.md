---
slug: "hash-e-grafo"
title: "Hashing e Grafos"
summary: "Tabelas de dispersão, representação de grafos e algoritmos básicos."
tags:
  - "hash"
  - "grafos"
youtube_playlists: []
contributors: []
---

Apresenta funções hash, tratamento de colisões, listas/matrizes de adjacência e percursos BFS/DFS.
