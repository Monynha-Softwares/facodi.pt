---
slug: "pesquisa"
title: "Pesquisa"
summary: "Busca linear e binária em coleções ordenadas e não ordenadas."
tags:
  - "pesquisa"
  - "busca"
youtube_playlists: []
contributors: []
---

Analisa requisitos e performance de cada método, apresentando casos de uso e variações.
