---
slug: "projeto-algoritmos"
title: "Projeto de Algoritmos"
summary: "Integração das estruturas estudadas em aplicações práticas."
tags:
  - "projetos"
  - "implementacao"
youtube_playlists: []
contributors: []
---

Desenvolve casos como gestão de filas, cálculo de caminhos e manipulação de matrizes esparsas.
