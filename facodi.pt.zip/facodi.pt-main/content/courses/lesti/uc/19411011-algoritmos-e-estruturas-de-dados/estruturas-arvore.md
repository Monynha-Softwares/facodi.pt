---
slug: "estruturas-arvore"
title: "Estruturas em Árvore"
summary: "Árvores binárias de busca, travessias e balanceamento AVL."
tags:
  - "bst"
  - "avl"
youtube_playlists: []
contributors: []
---

Trata inserção, remoção, percursos e rotação para manter árvores balanceadas.
