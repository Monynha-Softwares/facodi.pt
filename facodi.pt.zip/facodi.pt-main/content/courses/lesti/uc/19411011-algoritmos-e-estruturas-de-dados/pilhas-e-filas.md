---
slug: "pilhas-e-filas"
title: "Pilhas e Filas"
summary: "Estruturas LIFO e FIFO e aplicações típicas."
tags:
  - "pilha"
  - "fila"
youtube_playlists: []
contributors: []
---

Descreve operações, implementações em listas ou arrays e exemplos como call stack e gestão de filas de atendimento.
