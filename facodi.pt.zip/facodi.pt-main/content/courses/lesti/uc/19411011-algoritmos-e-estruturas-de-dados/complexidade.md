---
slug: "complexidade"
title: "Complexidade"
summary: "Princípios de análise assintótica de algoritmos."
tags:
  - "big-o"
  - "eficiencia"
youtube_playlists: []
contributors: []
---

Explora contagem de operações, classes de complexidade e comparação entre abordagens algorítmicas distintas.
