---
slug: "html-css-xml"
title: "HTML, CSS e XML"
summary: "Estruturação com HTML/XHTML, estilização com CSS e troca de dados via XML."
tags:
  - "html"
  - "css"
youtube_playlists: []
contributors: []
---

Apresenta elementos semânticos, formulários, seletores, layout responsivo e formato XML para configuração/dados.
