---
slug: "fundamentos-web"
title: "Fundamentos Web"
summary: "Evolução da Web, protocolo HTTP e arquitetura cliente-servidor."
tags:
  - "http"
  - "web"
youtube_playlists: []
contributors: []
---

Explora ciclo requisição-resposta, métodos HTTP e diferenciação entre sites estáticos e dinâmicos.
