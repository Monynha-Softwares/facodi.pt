---
slug: "desenvolvimento-web"
title: "Desenvolvimento Web"
summary: "Projeto integrador combinando frontend, backend e persistência."
tags:
  - "projeto"
  - "fullstack"
youtube_playlists: []
contributors: []
---

Propõe desenvolvimento de aplicação completa com autenticação básica, persistência e interface responsiva.
