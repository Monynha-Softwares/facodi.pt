---
slug: "javascript"
title: "JavaScript"
summary: "Programação cliente, manipulação de DOM e AJAX básico."
tags:
  - "javascript"
  - "dom"
youtube_playlists: []
contributors: []
---

Discute eventos, validação de formulários, fetch assíncrono e atualização dinâmica sem recarregar a página.
