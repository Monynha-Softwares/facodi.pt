---
slug: "php-e-backend"
title: "PHP e Backend"
summary: "Tratamento de requisições e integração com bases de dados usando PHP."
tags:
  - "php"
  - "backend"
youtube_playlists: []
contributors: []
---

Aborda superglobais, sessões, acesso a bases de dados e geração de HTML dinâmico no servidor.
