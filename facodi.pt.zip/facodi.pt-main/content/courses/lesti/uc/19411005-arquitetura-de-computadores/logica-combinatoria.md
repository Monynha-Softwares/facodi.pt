---
slug: "logica-combinatoria"
title: "Lógica Combinatória"
summary: "Álgebra booleana e implementação de circuitos combinatórios."
tags:
  - "booleano"
  - "circuitos"
youtube_playlists: []
contributors: []
---

Trabalha simplificação de expressões booleanas e construção de circuitos como descodificadores, multiplexadores e somadores.
