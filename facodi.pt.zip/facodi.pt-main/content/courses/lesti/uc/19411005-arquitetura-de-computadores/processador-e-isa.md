---
slug: "processador-e-isa"
title: "Processador e ISA"
summary: "Organização interna do CPU e conjunto de instruções."
tags:
  - "cpu"
  - "isa"
youtube_playlists: []
contributors: []
---

Analisa o ciclo fetch-decode-execute, modos de endereçamento, registos dedicados, ALU e mecanismos de chamadas, retornos e interrupções.
