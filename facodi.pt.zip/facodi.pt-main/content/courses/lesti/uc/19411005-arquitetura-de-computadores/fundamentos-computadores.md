---
slug: "fundamentos-computadores"
title: "Fundamentos de Computadores"
summary: "História da computação e estrutura básica de um computador moderno."
tags:
  - "historia"
  - "componentes"
youtube_playlists: []
contributors: []
---

Contextualiza a evolução das arquiteturas e identifica os componentes essenciais de um computador, incluindo CPU, memória e periféricos.
