---
slug: "sistemas-sequenciais"
title: "Sistemas Sequenciais"
summary: "Registos, memórias e mecanismos de controlo sequencial."
tags:
  - "registos"
  - "memorias"
youtube_playlists: []
contributors: []
---

Discute flip-flops, registos, contadores e memórias, mostrando como armazenar estado e sequenciar operações no processador.
