---
slug: "representacao-digital"
title: "Representação Digital"
summary: "Sistemas de numeração, aritmética e codificação de dados digitais."
tags:
  - "binario"
  - "codificacao"
youtube_playlists: []
contributors: []
---

Apresenta conversões entre bases, operações aritméticas binárias/hexadecimais e códigos para números e caracteres como ASCII e IEEE 754.
