---
slug: "hierarquia-memoria-io"
title: "Hierarquia de Memória e I/O"
summary: "Memória cache, virtual e interfaces de entrada/saída."
tags:
  - "memoria"
  - "io"
youtube_playlists: []
contributors: []
---

Descreve níveis da hierarquia de memória, políticas de substituição de cache, paginação, memória virtual e comunicação entre CPU e periféricos.
