---
slug: "arquitetura-fpga"
title: "Arquitetura de FPGA"
summary: "Estrutura interna de FPGAs modernos."
tags:
  - "fpga"
  - "arquitetura"
youtube_playlists: []
contributors: []
---

Apresenta LUTs, flip-flops, blocos DSP, memórias e desafios de roteamento e timing.
