---
slug: "ferramentas-cad-hdl"
title: "Ferramentas CAD HDL"
summary: "Fluxo de desenvolvimento com Vivado/Quartus, síntese e place-and-route."
tags:
  - "vivado"
  - "quartus"
youtube_playlists: []
contributors: []
---

Mostra leitura de relatórios, utilização de IP cores e geração de bitstream.
