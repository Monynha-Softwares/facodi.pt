---
slug: "vhdl-verilog"
title: "VHDL e Verilog"
summary: "Fundamentos das linguagens HDL, modelação combinatória e sequencial."
tags:
  - "vhdl"
  - "verilog"
youtube_playlists: []
contributors: []
---

Ensina sintaxe básica, simulação funcional e considerações de síntese para gerar hardware real.
