---
slug: "aplicacoes-fpga"
title: "Aplicações em FPGA"
summary: "Projeto prático de sistemas digitais reconfiguráveis."
tags:
  - "aplicacoes"
  - "prototipagem"
youtube_playlists: []
contributors: []
---

Propõe implementação de controladores, processadores soft-core ou aceleradores específicos e testes em placa.
