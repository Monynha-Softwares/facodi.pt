---
slug: "hardware-reconfiguravel"
title: "Hardware Reconfigurável"
summary: "Conceitos e motivação para reconfiguração pós-fabricação."
tags:
  - "fpga"
  - "hardware"
youtube_playlists: []
contributors: []
---

Discute diferenças entre hardware programável e fixo e casos de uso que beneficiam da flexibilidade.
