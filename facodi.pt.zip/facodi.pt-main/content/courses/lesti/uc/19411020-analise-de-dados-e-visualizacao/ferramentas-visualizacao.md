---
slug: "ferramentas-visualizacao"
title: "Ferramentas de Visualização"
summary: "Uso de Tableau, Power BI ou bibliotecas Python/R."
tags:
  - "tableau"
  - "power-bi"
youtube_playlists: []
contributors: []
---

Demonstra criação de gráficos, dashboards interativos e publicação/partilha de insights.
