---
slug: "pre-processamento-dados"
title: "Pré-processamento de Dados"
summary: "Limpeza, tratamento de valores omissos e normalização."
tags:
  - "dados"
  - "limpeza"
youtube_playlists: []
contributors: []
---

Apresenta técnicas para lidar com dados incompletos, inconsistentes ou em escalas distintas antes da análise.
