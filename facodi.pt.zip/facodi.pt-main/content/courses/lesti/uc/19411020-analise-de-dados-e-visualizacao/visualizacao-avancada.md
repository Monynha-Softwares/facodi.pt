---
slug: "visualizacao-avancada"
title: "Visualização Avançada"
summary: "Representação de séries temporais, mapas e dados multidimensionais."
tags:
  - "series"
  - "mapas"
youtube_playlists: []
contributors: []
---

Inclui gráficos com intervalos de confiança, mapas temáticos, diagramas de rede e redução de dimensionalidade para visualização.
