---
slug: "design-visualizacao"
title: "Design de Visualização"
summary: "Princípios perceptuais e escolha de gráficos adequados."
tags:
  - "visualizacao"
  - "design"
youtube_playlists: []
contributors: []
---

Explora melhores práticas, evita distorções e garante acessibilidade e clareza nas visualizações.
