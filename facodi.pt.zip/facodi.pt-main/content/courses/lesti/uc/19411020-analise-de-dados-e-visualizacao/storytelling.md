---
slug: "storytelling"
title: "Storytelling com Dados"
summary: "Construção de narrativas baseadas em evidências e dashboards finais."
tags:
  - "storytelling"
  - "dashboards"
youtube_playlists: []
contributors: []
---

Ensina a ordenar visualizações, contextualizar números e comunicar recomendações para públicos diversos.
