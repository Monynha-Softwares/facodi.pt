---
slug: "analise-exploratoria"
title: "Análise Exploratória"
summary: "Estatísticas descritivas e identificação de padrões e anomalias."
tags:
  - "eda"
  - "estatistica"
youtube_playlists: []
contributors: []
---

Utiliza histogramas, scatter plots, matrizes de correlação e resumo estatístico para compreender o dataset.
