---
slug: "conteudos-flexiveis"
title: "Conteúdos Flexíveis"
summary: "Programa variável definido pela UC optativa selecionada."
tags:
  - "optativa"
  - "flexivel"
youtube_playlists: []
contributors: []
---

Cada unidade optativa apresenta tópicos próprios que complementam a formação do estudante.
