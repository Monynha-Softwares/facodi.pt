---
title: "Opção II UAlg/ISE"
code: "19411038"
description: "Unidade optativa de 5 ECTS escolhida pelo aluno para aprofundar interesses específicos, conforme oferta disponível."
ects: 5
semester: 3
language: "pt"
prerequisites: []
learning_outcomes:
  - "Selecionar optativa alinhada à trilha de especialização desejada."
  - "Cumprir objetivos de aprendizagem definidos pela unidade escolhida."
  - "Integrar conhecimentos optativos às competências centrais da licenciatura."
youtube_playlists: []
summary: "Permite ao estudante escolher disciplinas complementares recomendadas para aprofundar trilhas tecnológicas ou de línguas."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

## Conteúdos Programáticos

Definidos pela unidade curricular optativa escolhida dentre as ofertas de 5 ECTS disponibilizadas pela UAlg/ISE para o semestre. Consulte a ficha oficial para detalhes de conteúdos, metodologias e avaliação.
