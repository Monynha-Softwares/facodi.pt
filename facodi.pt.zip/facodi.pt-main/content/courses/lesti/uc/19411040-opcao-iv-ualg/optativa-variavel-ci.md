---
slug: "optativa-variavel-ci"
title: "Optativa Variável CI"
summary: "Conteúdos definidos conforme a UC escolhida."
tags:
  - "optativa"
  - "ci"
youtube_playlists: []
contributors: []
---

Permite selecionar disciplinas avançadas de ciências informáticas ou áreas complementares.
