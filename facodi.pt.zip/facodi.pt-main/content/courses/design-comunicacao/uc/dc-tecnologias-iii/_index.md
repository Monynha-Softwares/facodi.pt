---
title: "Tecnologias III"
code: "14541147"
description: "Programação básica e integração de sistemas para comunicação digital."
ects: 5
semester: 3
language: "pt"
prerequisites:
  - "14541144"
learning_outcomes:
  - "Estruturar páginas responsivas com HTML/CSS"
  - "Integrar scripts simples para microinterações"
  - "Implementar fluxos de publicação e versionamento"
youtube_playlists:
  - id: "PLFACODI-DC-TEC3"
    priority: 1
summary: "Apresenta HTML, CSS e bibliotecas para prototipagem rápida."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

A disciplina apresenta fundamentos da web aberta, utilização de frameworks leves e noções de acessibilidade digital.
