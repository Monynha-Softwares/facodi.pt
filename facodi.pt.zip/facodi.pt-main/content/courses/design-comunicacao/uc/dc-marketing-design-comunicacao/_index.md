---
title: "Marketing em Design de Comunicação"
code: "14541191"
description: "Estratégias de posicionamento e promoção para projetos de design."
ects: 4
semester: 5
language: "pt"
prerequisites:
  - "14541012"
learning_outcomes:
  - "Construir personas e mapas de empatia"
  - "Planear campanhas integradas com indicadores mensuráveis"
  - "Criar planos de comunicação para portefólios profissionais"
youtube_playlists:
  - id: "PLFACODI-DC-MARKETING"
    priority: 1
summary: "Apresenta ferramentas de análise de público e planeamento de campanhas."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

A disciplina introduz conceitos de branding pessoal, marketing digital e métricas, alinhados com o universo do design de comunicação.
