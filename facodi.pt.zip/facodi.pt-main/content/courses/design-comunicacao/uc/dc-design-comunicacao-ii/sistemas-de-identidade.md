---
slug: "sistemas-de-identidade"
title: "Sistemas de Identidade"
summary: "Componentes modulares para construir marcas consistentes em múltiplos suportes."
tags:
  - "branding"
  - "guidelines"
  - "prototipagem"
youtube_playlists:
  - id: "PLFACODI-DC-TOPICO-005"
    priority: 1
contributors: []
---

Apresenta bibliotecas de componentes, exemplos de manuais de marca e exercícios de extensão de identidade para contextos físicos e digitais. Inclui entrevistas com estúdios nacionais sobre processos de co-criação com clientes.
