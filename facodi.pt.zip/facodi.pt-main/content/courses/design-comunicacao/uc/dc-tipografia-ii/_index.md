---
title: "Tipografia II"
code: "14541155"
description: "Aplicação avançada de tipografia em sistemas editoriais e digitais."
ects: 5
semester: 2
language: "pt"
prerequisites:
  - "14541153"
learning_outcomes:
  - "Construir sistemas tipográficos multiplataforma"
  - "Desenhar lettering autoral alinhado ao conceito"
  - "Documentar boas práticas de tipografia para equipas de design"
youtube_playlists:
  - id: "PLFACODI-DC-TIPO2"
    priority: 1
summary: "Explora grelhas modulares, tipografia responsiva e motion type."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

São desenvolvidos projetos editoriais complexos, animações tipográficas e guidelines para equipas multidisciplinares.
