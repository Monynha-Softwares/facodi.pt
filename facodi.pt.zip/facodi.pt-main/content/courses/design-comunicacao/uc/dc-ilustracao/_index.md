---
title: "Ilustração"
code: "14541145"
description: "Exploração de técnicas analógicas e digitais para criação de narrativas visuais."
ects: 4
semester: 3
language: "pt"
prerequisites:
  - "14541142"
learning_outcomes:
  - "Experimentar linguagens gráficas diversas"
  - "Integrar ilustração em projetos multidisciplinares"
  - "Construir portefólio ilustrado alinhado com o mercado"
youtube_playlists:
  - id: "PLFACODI-DC-ILUSTRACAO"
    priority: 1
summary: "Desenvolve estilos autorais aplicados a editorial, branding e motion."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

A disciplina incentiva pesquisa iconográfica e prática contínua com tablets gráficos, técnicas mistas e animação frame a frame.
