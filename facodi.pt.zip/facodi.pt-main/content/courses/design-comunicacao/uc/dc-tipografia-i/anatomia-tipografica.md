---
slug: "anatomia-tipografica"
title: "Anatomia Tipográfica"
summary: "Guia ilustrado sobre componentes de letras e implicações na legibilidade."
tags:
  - "tipografia"
  - "editorial"
  - "legibilidade"
youtube_playlists:
  - id: "PLFACODI-DC-TOPICO-003"
    priority: 1
contributors: []
---

Inclui diagramas interativos, exercícios de identificação e estudos de caso comparando famílias serifadas e sem serifa. Os recursos complementam atividades de desenho manual e digital propostas nas aulas práticas.
