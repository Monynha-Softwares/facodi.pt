---
title: "Língua Estrangeira - Espanhol"
code: "14541166"
description: "Competências comunicacionais em espanhol com foco na indústria criativa."
ects: 4
semester: 5
language: "pt"
prerequisites: []
learning_outcomes:
  - "Conduzir reuniões e briefings em espanhol"
  - "Redigir relatórios e propostas profissionais"
  - "Apresentar portefólio a públicos hispânicos"
youtube_playlists:
  - id: "PLFACODI-DC-ESPANHOL"
    priority: 1
summary: "Amplia possibilidades de cooperação ibero-americana em projetos de design."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

A unidade utiliza role-playing, análise de campanhas hispânicas e exercícios de tradução aplicada ao design.
