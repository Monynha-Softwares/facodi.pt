---
title: "Fotografia I"
code: "14541184"
description: "Fundamentos técnicos e estéticos da fotografia digital aplicada ao design."
ects: 4
semester: 3
language: "pt"
prerequisites: []
learning_outcomes:
  - "Operar câmaras em modo manual"
  - "Planear sessões fotográficas alinhadas ao conceito"
  - "Realizar pós-produção básica com fluxos RAW"
youtube_playlists:
  - id: "PLFACODI-DC-FOTO1"
    priority: 1
summary: "Controla exposição, composição e tratamento de imagem para campanhas visuais."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

A unidade cobre iluminação de estúdio, fotografia de produto e retrato. São realizados exercícios em exteriores e laboratórios digitais.
