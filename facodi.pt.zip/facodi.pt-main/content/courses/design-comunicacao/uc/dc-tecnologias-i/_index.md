---
title: "Tecnologias I"
code: "14541143"
description: "Introdução às ferramentas digitais essenciais para o design gráfico."
ects: 5
semester: 1
language: "pt"
prerequisites: []
learning_outcomes:
  - "Utilizar aplicações de edição vetorial para preparar artes finais"
  - "Gerir ficheiros e formatos adequados a impressão e web"
  - "Integrar atalhos e boas práticas de produtividade digital"
youtube_playlists:
  - id: "PLFACODI-DC-TEC1"
    priority: 1
summary: "Trabalha fluxo de produção com software de edição vetorial e de imagem."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

Os estudantes aprendem ferramentas Adobe e alternativas open-source, configurando perfis de cor, exportação e gestão de fontes. Exercícios semanais reforçam a aplicação das ferramentas em briefs reais.
