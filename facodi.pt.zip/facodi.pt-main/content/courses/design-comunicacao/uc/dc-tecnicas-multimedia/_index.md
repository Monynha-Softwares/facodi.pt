---
title: "Técnicas Multimédia"
code: "14541183"
description: "Introdução à produção de conteúdos interativos com som, vídeo e animação."
ects: 5
semester: 3
language: "pt"
prerequisites:
  - "14541144"
learning_outcomes:
  - "Produzir animações curtas para suportes digitais"
  - "Sincronizar áudio, vídeo e grafismos"
  - "Planejar fluxos de interação simples para experiências digitais"
youtube_playlists:
  - id: "PLFACODI-DC-MULTIMEDIA"
    priority: 1
summary: "Cria protótipos multimédia alinhados com narrativas interativas."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

Os projetos incluem motion graphics, vídeos curtos e experiências interativas utilizando ferramentas low-code.
