---
title: "Fotografia Analógica"
code: "14541189"
description: "Introdução a processos fotográficos analógicos e laboratório de revelação."
ects: 4
semester: 5
language: "pt"
prerequisites:
  - "14541184"
learning_outcomes:
  - "Operar equipamentos analógicos de forma segura"
  - "Revelar e ampliar fotografias em laboratório"
  - "Combinar workflows analógicos e digitais em projetos"
youtube_playlists:
  - id: "PLFACODI-DC-FOTO-ANALOGICA"
    priority: 1
summary: "Explora câmaras analógicas, película e ampliação em câmara escura."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

A unidade recupera práticas de laboratório, incentivando experimentação e compreensão material da imagem fotográfica.
