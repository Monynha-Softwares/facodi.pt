---
slug: "processo-criativo-colaborativo"
title: "Processo Criativo Colaborativo"
summary: "Metodologias para transformar insights em conceitos visuais testáveis."
tags:
  - "metodologias"
  - "prototipagem"
  - "co-criacao"
youtube_playlists:
  - id: "PLFACODI-DC-TOPICO-001"
    priority: 1
contributors: []
---

Explora ferramentas como design sprint, mapa de empatia e storyboard para acelerar decisões coletivas. Inclui fichas de trabalho, templates editáveis e exemplos de documentação de processos utilizados em estúdios colaborativos.
