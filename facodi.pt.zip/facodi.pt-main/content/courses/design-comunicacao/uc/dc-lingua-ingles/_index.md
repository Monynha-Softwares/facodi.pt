---
title: "Língua Estrangeira - Inglês"
code: "14541165"
description: "Desenvolvimento de competências linguísticas aplicadas ao contexto profissional do design."
ects: 4
semester: 5
language: "pt"
prerequisites: []
learning_outcomes:
  - "Redigir apresentações e propostas em inglês"
  - "Participar em reuniões e críticas com fluência"
  - "Construir portefólio e currículo em formato internacional"
youtube_playlists:
  - id: "PLFACODI-DC-INGLES"
    priority: 1
summary: "Foca comunicação oral, escrita e terminologia técnica em inglês."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

A unidade curricular utiliza projetos simulados com clientes internacionais, exercícios de pitching e análise de referências globais.
