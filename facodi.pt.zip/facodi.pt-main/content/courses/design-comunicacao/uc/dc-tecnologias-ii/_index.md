---
title: "Tecnologias II"
code: "14541144"
description: "Continuação das competências digitais com foco em edição de imagem avançada e prototipagem interativa."
ects: 5
semester: 2
language: "pt"
prerequisites:
  - "14541143"
learning_outcomes:
  - "Criar protótipos navegáveis para interfaces web"
  - "Aplicar técnicas de edição não destrutiva"
  - "Automatizar tarefas recorrentes nas suites criativas"
youtube_playlists:
  - id: "PLFACODI-DC-TEC2"
    priority: 1
summary: "Aprofunda fluxos de trabalho para conteúdos digitais responsivos."
type: "uc"
cascade:
  type: "topic"
contributors: []
---

Os estudantes trabalham com ferramentas de prototipagem e sistemas de design, explorando componentes reutilizáveis e colaboração em nuvem.
